# PRD — Ketupat Rush
### A 3D casual cooking and food-assembly game set in an Indonesian Lebaran food stall

| | |
|---|---|
| **Version** | 1.0 (implementation-ready draft) |
| **Date** | 25 November 2026 |
| **Document status** | Single source of truth for AI-assisted development. No code has been written yet. |
| **Platforms** | Desktop browsers (landscape) and mobile browsers (portrait only) |
| **Recommended stack** | TypeScript + Vite + Three.js (WebGL), DOM/CSS HUD, vanilla Zustand store, Web Audio |
| **Language** | Game UI in Bahasa Indonesia (i18n-ready). This document in English. |

---

## 0. How to Read This Document

### 0.1 Labels used
| Label | Meaning |
|---|---|
| **[CONFIRMED]** | Stated by the product owner in the master brief. Do not change without approval. |
| **[VERIFIED]** | A research finding confirmed from a public source during this research pass (source listed in section 5.5). |
| **[ASSUMPTION]** | A design assumption or recommendation. Reasonable default; may be tuned. |
| **[OPEN]** | A decision still needed from the product owner (section 0.3). |

### 0.2 Confirmed requirements (summary)
1. Title **Ketupat Rush**; casual cooking, food assembly, time management; Indonesian Eid al-Fitr theme. [CONFIRMED]
2. Player runs a small food stall; customers order Lebaran dishes; player assembles a plate; serves; gets paid; customers have patience timers. [CONFIRMED]
3. Desktop and mobile browsers. Mobile is **always portrait (9:16 preferred)** and must never switch to a landscape layout, even if the phone is rotated. [CONFIRMED]
4. Cute, polished, appetizing **3D cartoon** visuals. Every food is a separate 3D asset; no flat 2D or emoji-style food. [CONFIRMED]
5. Background music **and** sound effects are mandatory, with separate music and SFX controls. [CONFIRMED]
6. Four levels: Lebaran Pertama, Warung Mulai Ramai, Open House, Puncak Silaturahmi. [CONFIRMED]
7. Food list: Ketupat, Lontong; Opor Ayam, Rendang, Semur Daging, Ayam Goreng; Sambal Goreng Kentang, Sayur Labu Siam, Telur Balado, Perkedel; Bawang Goreng, Kerupuk, Sambal, Emping. [CONFIRMED]
8. Palette: warm cream, emerald green, soft yellow, warm orange, light brown, festive accents. [CONFIRMED]

### 0.3 Open questions for the product owner [OPEN]
| ID | Question | Default used in this PRD |
|---|---|---|
| OQ-1 | Final stack preference: Vite + TypeScript, or no-build vanilla JS (as in previous projects)? | Vite + TypeScript (section 18) |
| OQ-2 | Who produces the music: procedural in-browser synthesis, a human composer, or an AI music tool with commercial license? | Procedural synthesis for MVP; OGG/MP3 drop-in replacement supported |
| OQ-3 | Are AI image-to-3D tools (Tripo, Meshy) acceptable for character bases, with license check? | Not used; procedural builders for MVP |
| OQ-4 | Is progress persistence on the device (localStorage) enough, or is an online leaderboard wanted later? | localStorage only |
| OQ-5 | English UI needed at launch? | Indonesian only; i18n keys prepared |
| OQ-6 | Is a spending loop (stall upgrades with earned money) wanted in MVP? | Post-MVP (section 27) |

---

## 1. Executive Summary

Ketupat Rush is a short-session, time-management cooking game. The player runs a warung (food stall) during Lebaran. Customers walk up with an order bubble listing traditional dishes. The player taps or drags ingredients onto a plate, checks it, serves it to the correct customer before the patience bar runs out, and collects money and tips. Four levels raise customer traffic, order complexity, and time pressure.

The core difficulty is **order accuracy, speed, and multi-customer prioritization**, not complicated cooking steps. Interaction is built for one thumb on a phone and for mouse or keyboard on a desktop. The look is a soft, toy-like 3D world with warm lighting, Islamic geometric motifs, and ketupat ornaments. Audio is a cheerful, original instrumental loop plus responsive sound effects.

**Primary deliverable of this phase:** this PRD. Coding starts only after approval.

## 2. Product Vision

> "A warm, festive, one-more-round game that makes players hungry, smile, and feel the joy of Lebaran hospitality."

| Pillar | Meaning |
|---|---|
| **Instantly readable** | A new player understands an order bubble and the plate within 5 seconds, without a long tutorial. |
| **Appetizing** | Every dish looks delicious and recognizably Indonesian. |
| **Fair pressure** | Difficulty rises gradually; mistakes are recoverable; losses feel earned. |
| **Respectful festivity** | Lebaran is celebrated warmly and inclusively; religious recitations are not used as music or SFX. |
| **Light and fast** | Loads quickly and runs smoothly on mid-range phones. |

Success metrics (targets for the first release): tutorial completion ≥ 85% of new sessions; level 1 completion ≥ 70%; average session ≥ 6 minutes; crash-free sessions ≥ 99.5%; 60 FPS desktop; ≥ 30 FPS floor on mid-range Android. [ASSUMPTION]

## 3. Target Audience

| Segment | Description | Needs |
|---|---|---|
| Primary | Indonesian players aged 10–40 on smartphones, short sessions during the Lebaran season | One-handed portrait play, quick restarts, Indonesian text |
| Secondary | Desktop visitors of a Lebaran microsite or portal | Comfortable mouse play, keyboard shortcuts, use of wide screens |
| Tertiary | Families playing together or watching | Readable visuals, family-friendly content |

Content rating target: suitable for all ages; no violence, no gambling mechanics, no real-money purchases. [ASSUMPTION]

## 4. Game Concept and Core Experience

**Premise [CONFIRMED]:** the player manages a small Indonesian food stall during Lebaran. Customers arrive with different preferences. The player assembles the requested dish combination on a plate and serves it for payment. Impatient customers leave.

**Fantasy:** being the beloved warung owner whose table is the busiest in the neighborhood during Open House.

**Differentiation from references (original identity):**
- Lebaran food system with a **category-based plate** (carb, main, sides, topping, sauce, crunch) rather than stacked layers or timed cooking steps.
- **Open House** wave events and family customers with larger orders.
- A visual world built on ketupat ornaments, lanterns, Islamic geometric patterns, and Lebaran fashion (baju koko, gamis, kebaya, sarung, peci, hijab).
- A **no-cooking-timer** philosophy: food is prepared "ready to plate"; challenge is prioritization and accuracy.

**Session shape:** one shift = 2 to 3.5 minutes. Menu → level select → shift → result → retry or next.

## 5. Competitor and Reference Game Research

Research was done from public sources only. Nothing is copied. Findings are labeled [VERIFIED] (with sources in 5.5) or [ASSUMPTION].

### 5.1 Reference game analysis

| Game | Core loop (verified facts) | Ordering | Assembly / interaction | Patience, money, tips | Progression | Takeaway for Ketupat Rush |
|---|---|---|---|---|---|---|
| **Good Pizza, Great Pizza** (TapBlaze) | Take order → build → bake → slice → box → serve. [VERIFIED] | Orders vary in amount of toppings, slices; customers can be vague; the player may ask once for clarification and re-read a receipt. [VERIFIED] | Tap ingredient containers to add and tap again to stop; over-using toppings costs money and draws complaints. [VERIFIED] | Speed and quality influence tips; refunds exist; the game can end when the day's profit is negative (Arcade edition). [VERIFIED] | Day-by-day; more complex orders; new toppings and equipment bought with money. [VERIFIED] | Personality-rich customers, readable receipts, tip-for-quality. Reviewers call the loop **repetitive** and note weak reward for accuracy [VERIFIED], so Ketupat Rush adds waves, combos, and varied customer archetypes. |
| **Papa's Burgeria** (Flipline) | Take order, grill, build burger on ticket order, serve. [VERIFIED] | Order ticket on a string; customers wait in line and a lobby. [VERIFIED] | Drag toppings and sauces in the listed order; sauces cannot be removed once added. [VERIFIED] | Waiting too long to take or prepare an order loses points; upgrades make customers wait longer. [VERIFIED] | Tips buy upgrades; points raise rank and unlock customers. [VERIFIED] | Strong multitask feel and clear tickets. Irreversible actions are harsh for casual players, so Ketupat Rush allows removal. The "To Go" version adds buttons to switch tickets on small screens. [VERIFIED] This is adopted for mobile. |
| **Burger Please!** (Supercent) | Grill patties, stack ingredients, serve, expand menu and franchise. [VERIFIED] | Customers order burgers; later pizza and more items. [VERIFIED] | Hands-on stacking with upgrades and bonuses. [VERIFIED] | Rewards through upgrades and bonuses. [VERIFIED] | Menu expansion and franchise growth. [VERIFIED] | Satisfying "growth" feedback. Ketupat Rush uses ingredient unlocks per level as the growth driver in MVP. |
| **Cooking Fever** (Nordcurrent) | Time-managed service across many levels. [VERIFIED] | Multi-item orders; serving one item restores some patience. [VERIFIED] | Tap-driven preparation and serving. [VERIFIED] | Mood stages (happy → concerned → sad → angry) before leaving [VERIFIED, secondary guide]; combos start after two quick serves, with bonus coins on each dish after the second; up to five in a row. [VERIFIED] | Levels with goals (earn coins or serve a number of dishes), time or other restrictions, stars, upgrades, achievements. [VERIFIED] | Level goals, combos, and visible mood stages are adopted. |
| **Burger Shop / Burger Rush (genre peers)** | Click ingredients to combine and serve; customers have different patience; faster service tips more; occasional bonus items. [VERIFIED] | Grid or ingredient matching. [VERIFIED] | Click-driven. [VERIFIED] | Patience affects tip; customers may storm out. [VERIFIED] | Many levels with upgrades. [VERIFIED] | Confirms "serve the least patient first" as a core skill. |
| **Cooking Mama** | Mini-game per cooking step. [ASSUMPTION: not researched in this pass; from general knowledge] | N/A | Gesture mini-games | Score by performance | Recipes | Not adopted; Ketupat Rush avoids multi-step cooking mini-games to keep focus on accuracy and speed. |

### 5.2 Patterns adopted
1. Ticket/bubble with icons; clear visual order. 2. Patience bar with mood faces. 3. Tips tied to patience remaining. 4. Combo streaks with a short window. 5. Level goals plus stars. 6. Unlock-driven complexity. 7. Multiple customers simultaneously with a hard cap. 8. Allowing mistakes to be corrected (soft failure).

### 5.3 Patterns deliberately avoided
Long cooking timers, irreversible sauce placement, real-money boosters, energy/lives gating, rewarded-ads interruptions, and unclear refunds (a common complaint in reviews). [ASSUMPTION]

### 5.4 UI/UX, art, and audio observations (assumptions from genre norms)
Cozy, soft-shaded 3D with bright warm palettes; large rounded buttons; coin/tip popups; short celebratory stingers; looping upbeat music with light percussion; ASMR-like placement sounds (Good Pizza, Great Pizza even markets its sound design and official soundtrack [VERIFIED]).

### 5.5 Sources consulted (public)
- Apple App Store listings: Good Pizza, Great Pizza (apps.apple.com/us/app/id911121200) and Good Pizza, Great Pizza+ (id6752314651); Burger Please! (id1668713081); Papa's Burgeria (id514634235) and Papa's Burgeria To Go (id600626116).
- Wikipedia (via Wikiwand): Good Pizza, Great Pizza gameplay summary.
- Common Sense Media: Good Pizza, Great Pizza review.
- Flipline official FAQ: i.flipline.com/games/papasburgeria/faq.html.
- Gamezebo (Burger Rush review); MobyGames (Burger Shop); touchtapplay.com; pocketgamer.com; levelwinner.com guides (Cooking Fever, secondary sources).
- Cooking Live help center (Matryoshka Games): level goals and combos FAQ.
- Tech: LogRocket and Utsubo comparisons (Three.js, Babylon.js, PlayCanvas); A-Frame docs on glTF compression; caniuse.com and WebKit Bugzilla on Screen Orientation lock; Kenney, Quaternius, KayKit asset pages.

### 5.6 Research limitations
No reliable public architecture or source-code documentation was found for the commercial reference titles in this pass; the PRD does not depend on it. Details marked [ASSUMPTION] should be validated with playtests.

---

## 6. Core Gameplay Loop

```
[Customer arrives] -> [Order bubble appears] -> [Player reads order]
      -> [Select plate] -> [Add ingredients (tap or drag)] -> [Review plate / remove mistakes]
      -> [Serve to the correct customer] -> [Validation]
            |-- correct -> [Customer reacts + pays + tip] -> [Money, score, combo update] -> next customer
            |-- wrong   -> [Plate returned with mismatch hints, patience penalty] -> fix and re-serve
      -> (parallel) [Other customers' patience drains; impatient customers leave]
Shift ends (timer) -> [Result: revenue vs target, stars] -> retry or next level
```

Micro-loop (5–10 seconds): read bubble → 3–5 taps → serve. Macro-loop (2–3.5 minutes): manage up to four customers, hit the revenue target, avoid losing too many customers.

---

## 7. Detailed Gameplay Mechanics

### 7.1 Plate model (category-based assembly)
A plate has **seven fixed placement points**, one per ingredient category. This makes placement predictable on touch screens and trivial to validate.

| Slot ID | Category | Capacity | Items | Visual position on plate |
|---|---|---|---|---|
| `carb` | Main component | 1 | Ketupat, Lontong | Left-center |
| `main` | Main dish | 1 | Opor Ayam, Rendang, Semur Daging, Ayam Goreng | Center |
| `side` | Side dishes | up to 2 (distinct) | Sambal Goreng Kentang, Sayur Labu Siam, Telur Balado, Perkedel | Right-top and right-bottom |
| `topping` | Topping | 1 | Bawang Goreng | Sprinkled over `main`/`carb` |
| `sauce` | Sauce | 1 | Sambal | Small dollop near the edge |
| `crunch` | Crunchy extra | 1 | Kerupuk, Emping | Leaning on the back edge |

Rules:
- Ingredients are **unlimited**; there is no stock management in MVP. [ASSUMPTION]
- Adding to an occupied single-capacity slot **replaces** the item (the old item animates off). A replacement counts as a removal for fee and "perfect order" purposes.
- Order of placement does not matter. Validation compares **sets**.

### 7.2 Order model
An order is a set of ingredient IDs, with these constraints: exactly 1 `carb` and exactly 1 `main` (always required); 0–2 `side`; 0–1 `topping`; 0–1 `sauce`; 0–1 `crunch`. Min 2 items, max 7 items.

Examples (from the brief):
- Order A: Ketupat, Opor Ayam, Sambal Goreng Kentang, Bawang Goreng
- Order B: Ketupat, Rendang
- Order C: Lontong, Opor Ayam, Telur Balado, Kerupuk

### 7.3 Interaction model (touch and mouse)
| Action | Mobile (portrait) | Desktop |
|---|---|---|
| Select customer/order | Tap order bubble or customer | Click order card or customer |
| Add ingredient | **Tap** ingredient button: item flies to its slot on the active plate (1 tap = 1 item). Drag-to-plate also supported. | Click, or drag and drop to the plate; hotkeys 1–9 |
| Remove ingredient | Tap a placed item on the plate (confirm by item pop-out) or drag it to the trash | Click placed item, right-click, or Backspace (removes last) |
| Clear plate | "Clear" button (trash) | Same, or `C` |
| Switch plate (Level 2+) | Tap plate tab A/B, or swipe on counter | Click plate, or `Tab` |
| Serve | Drag plate onto a customer, **or** with a customer selected tap **Serve** | Drag, click **Serve**, or `Space` |
| Pause | Top-right button | Button, `Esc`, or `P` |

Selecting a customer is optional. If the player taps **Serve** without a selected customer, the game serves to the customer whose order **best matches** the plate (exact match first; otherwise the lowest-patience customer is targeted and the validation fails with hints). [ASSUMPTION]

### 7.4 Serving validation
```
required = order.items (set)    placed = plate.items (set)
missing  = required - placed    extra = placed - required
CORRECT if missing is empty AND extra is empty.
```
**Wrong order handling (soft failure):**
1. The customer shows an "angry" reaction and a short sound plays.
2. Patience decreases by **30% of the customer's maximum patience**.
3. The plate returns to the counter. Mismatching items are marked with a red outline (extra) or a dashed ghost icon (missing). Hints are shown in all levels except an optional hardcore mode. [ASSUMPTION]
4. The combo streak resets. No immediate cash penalty.
5. Serving the same wrong plate to the same customer twice within 3 seconds is ignored (prevents spam).
6. Each level tracks **mistakes**; 3 or more mistakes cost one star in the star rating (section 10).

### 7.5 Multiple customers and plates
- Active customers at once: L1 = 2, L2 = 3, L3 = 4, L4 = 4 (section 10). The spawn timer pauses while the counter is full (no off-screen queue).
- Plates in preparation: L1 = 1, L2+ = **2** (A and B). More plates are a post-MVP upgrade.
- A plate is bound to nothing until served. Any plate can be served to any customer.

### 7.6 Patience system
- Each customer has `patienceMax` seconds (formula in section 9.4) that drains in real time while the order is visible.
- Mood stages by remaining ratio `p`: **Happy** p > 0.66, **Neutral** 0.33 < p ≤ 0.66, **Impatient** p ≤ 0.33 (bar turns red, face sweats, soft alert sound), **Leaves** p = 0.
- Patience does not drain during Pause, tutorial hint modals, or the 3-second pre-shift countdown.
- A customer who leaves angry counts as **lost**; the combo resets; revenue is reduced by the leave fee (section 11).

### 7.7 Feature specifications

Each feature uses: description, user stories, functional requirements (FR), interaction flow, edge cases, acceptance criteria (AC), dependencies.

#### F01 — Order display
- **Description:** Each customer shows a bubble with icons for every required ingredient and a patience bar. Desktop also shows an order list.
- **User stories:** As a player I can see what each customer wants at a glance; as a mobile player the bubbles never hide the plate.
- **FR:** FR-010 bubble appears within 0.8 s of arrival; FR-011 icons are 3D-rendered thumbnails or SVG silhouettes matching the 3D food colors; FR-012 icons ordered by slot order (carb, main, sides, topping, sauce, crunch); FR-013 selected order is highlighted.
- **Flow:** arrive → bubble pop → patience starts.
- **Edge cases:** 7-item order must fit the bubble (two rows); two customers with identical orders must be distinguishable by customer color tag.
- **AC:** bubble text-free and readable at 360 px width; 7-item order fits without clipping; verified in screenshots.
- **Dependencies:** customer system, UI layer, asset thumbnails.

#### F02 — Ingredient selection and placement
- **Description:** Tap or drag ingredient buttons to place items on the active plate.
- **User stories:** As a player I add an ingredient with one tap; as a desktop player I can also drag.
- **FR:** FR-020 tap adds to the correct slot; FR-021 drag shows a ghost and snaps to the slot; FR-022 placement animation ≤ 250 ms; FR-023 audio feedback; FR-024 locked ingredients are hidden or shown dimmed with an unlock level.
- **Flow:** tap button → item flies (parabola) → lands → squash feedback → slot filled.
- **Edge cases:** double-tap on the same ingredient does nothing (already placed); fast tapping across categories must not drop inputs; tapping while a plate is flying to a customer is queued for the next plate.
- **AC:** 10 rapid taps in 3 seconds all register (when valid); no ingredient appears in a wrong slot.
- **Dependencies:** plate model, input layer, audio.

#### F03 — Plate review and removal
- **Description:** Placed items can be removed individually or the plate can be cleared.
- **FR:** FR-030 tap placed item removes it with a pop-out animation; FR-031 clear plate removes all; FR-032 removal fee applies from Level 3 (section 11); FR-033 undo is not provided.
- **Edge cases:** removing while the plate is being served is blocked; removal on an empty slot does nothing.
- **AC:** removal responds within 100 ms; fee displayed in a floating label.

#### F04 — Serving and validation
- **Description:** See 7.3 and 7.4.
- **FR:** FR-040 exact-match validation; FR-041 correct serve triggers payment sequence; FR-042 wrong serve triggers 7.4 behavior; FR-043 serve with an empty plate is rejected with a gentle shake.
- **Flow:** drag or press Serve → plate slides to customer → validation → reaction.
- **Edge cases:** customer leaves during the plate's flight: the plate returns to the counter, no penalty; two taps on Serve produce one serve.
- **AC:** 100 scripted validation cases pass (unit tests, section 25).

#### F05 — Customer lifecycle and patience
- **Description:** See sections 7.6 and 9.
- **FR:** FR-050 states and animations per section 9.3; FR-051 patience formula per 9.4; FR-052 leave penalty per section 11.

#### F06 — Customer spawner
- **Description:** Seeded random spawning with intervals, caps, and rush waves per level.
- **FR:** FR-060 first customer at 1.5 s; FR-061 spawn only if active < maxActive; FR-062 rush waves per level config; FR-063 no spawns during the closing phase (last 15 s); FR-064 deterministic with a seed for tests.

#### F07 — Economy and scoring
- **Description:** Section 11.
- **FR:** FR-070 payment formula; FR-071 tip tiers; FR-072 combo; FR-073 leave fee; FR-074 stars.
- **AC:** unit tests reproduce the example calculations in section 11.5.

#### F08 — Level flow
- **Description:** Level intro → 3-second countdown → shift → closing → result.
- **FR:** FR-080 objectives and failure rules per section 10; FR-081 results screen with revenue, stars, and breakdown; FR-082 next level unlocks on ≥ 1 star.

#### F09 — Responsive layout and portrait enforcement
- **Description:** Section 13.
- **FR:** FR-090 mobile portrait stage always; FR-091 desktop landscape layout; FR-092 resize and orientation events are handled without losing state.
- **AC:** viewports in section 13.4 verified by screenshots.

#### F10 — Audio
- **Description:** Section 17.
- **FR:** FR-100 music and SFX independent volume/mute; FR-101 audio starts after the first user gesture; FR-102 pause on tab hidden.

#### F11 — Settings and persistence
- **FR:** FR-110 settings persisted; FR-111 progress (stars, best revenue per level) persisted; FR-112 storage failures are handled silently.

#### F12 — Onboarding
- **Description:** Level 1 contextual hints (no long tutorial): highlight the first customer, show an arrow to the needed ingredient, then the Serve button. Skippable; shown once.
- **FR:** FR-120 hints appear only in the first shift; FR-121 patience paused during hint modals; FR-122 hints can be disabled in Settings.

#### F13 — Loading
- **FR:** FR-130 loading screen with a ketupat-weaving progress animation; FR-131 interactive within 3 s on a fast connection; FR-132 later levels' assets loaded lazily.

#### F14 — Pause and restart
- **FR:** FR-140 pause freezes timers, patience, and animations (music ducks); FR-141 restart level; FR-142 quit to menu with a confirmation.

---

## 8. Food and Ingredient Database

### 8.1 Ingredient table [CONFIRMED list; prices and unlocks are ASSUMPTIONS]
Prices are in Indonesian rupiah (Rp) and are the ingredient's contribution to an order's value.

| ID | Display name (ID) | Category / slot | Price (Rp) | Unlock level | Visual representation (3D) |
|---|---|---|---|---|---|
| `ketupat` | Ketupat | carb | 3.000 | 1 | Diamond-shaped rice cake in woven green-gold coconut-leaf pattern; procedural weave texture (diagonal crossing strips) with bump; cut open into two slices showing soft cream rice |
| `lontong` | Lontong | carb | 2.500 | 2 | Cylinder rice cake wrapped in banana leaf, cut into 3 rounds with a leaf wrap piece |
| `opor_ayam` | Opor Ayam | main | 12.000 | 1 | Small bowl of creamy yellow (#F2D27A) coconut curry with 2 chicken pieces, tiny oil droplets, lemongrass and a kaffir lime leaf |
| `rendang` | Rendang | main | 15.000 | 1 | 3 glossy dark-brown (#5A2E1B) beef chunks with a rich sauce sheen, lemongrass and turmeric-leaf bits |
| `semur_daging` | Semur Daging | main | 13.000 | 2 | Soy-braised beef (#6B3B22) with potato wedge and fried shallot flecks, glossy sauce |
| `ayam_goreng` | Ayam Goreng | main | 11.000 | 2 | One golden-brown (#D99A3C) drumstick plus thigh, crispy bumpy surface |
| `sambal_goreng_kentang` | Sambal Goreng Kentang | side | 5.000 | 2 | Glossy red-orange (#D9482B) potato cubes with chili strips and a few green pepper bits |
| `sayur_labu_siam` | Sayur Labu Siam | side | 4.000 | 3 | Light-green chayote chunks (#C9D88A) with soft yellow broth and a red chili slice |
| `telur_balado` | Telur Balado | side | 4.500 | 2 | Halved boiled egg coated with red balado sambal (#C8321F), yolk visible |
| `perkedel` | Perkedel | side | 3.500 | 3 | Two golden potato patties with slight crust texture |
| `bawang_goreng` | Bawang Goreng | topping | 1.000 | 3 | Small pile of crispy brown shallot flakes (#9A5B24) scattered with random rotation |
| `kerupuk` | Kerupuk | crunch | 1.500 | 3 | Pale-cream (#F3DDA0) round cracker with a bubbly surface leaning on the plate edge |
| `sambal` | Sambal | sauce | 1.000 | 3 | Glossy red (#C0261A) dollop with seeds and a cap shine |
| `emping` | Emping | crunch | 2.000 | 4 | Thin sand-colored (#D9B77A) disc chips, 2 stacked slightly overlapping |

Unlock summary: L1 = 3 items (ketupat, opor, rendang); L2 adds lontong, semur, ayam goreng, sambal goreng kentang, telur balado (8 total); L3 adds sayur labu siam, perkedel, bawang goreng, kerupuk, sambal (13 total); L4 adds emping (14 total).

### 8.2 Order combination rules
- 1 carb + 1 main always; sides, topping, sauce, crunch optional, limited by what is unlocked in the level.
- Item count distribution per level (probability): L1: 2 items 100%. L2: 2 items 30%, 3 items 50%, 4 items 20%. L3: 3 items 25%, 4 items 45%, 5 items 30%. L4: 4 items 25%, 5 items 45%, 6 items 25%, 7 items 5%.
- The same exact order is never generated for two consecutive customers.
- Ingredient popularity weights (default 1.0; rendang 1.2, opor ayam 1.2, ketupat 1.3) keep the most iconic dishes frequent.

### 8.3 Placement positions (plate-local coordinates, plate radius = 1.0)
`carb` (-0.38, 0, 0.05) · `main` (0.02, 0, 0.05) · `side[0]` (0.50, 0, -0.30) · `side[1]` (0.50, 0, 0.38) · `topping` (0.02, +0.18 y over main) · `sauce` (-0.05, 0, -0.62) · `crunch` (-0.15, 0, 0.70) leaning at 25 degrees.

### 8.4 Modularity requirement
All ingredient data lives in `data/ingredients.json`. Adding a new ingredient (for example, Lemang) requires only: a JSON entry, a builder or GLB registered under `food_<id>`, an icon, and (optionally) a new slot rule. No gameplay code change.

### 8.5 Example JSON
```json
{
  "id": "opor_ayam",
  "nameKey": "food.opor_ayam",
  "slot": "main",
  "price": 12000,
  "unlockLevel": 1,
  "weight": 1.2,
  "asset": { "model": "food_opor_ayam", "icon": "ui_icon_food_opor_ayam" },
  "sfx": "sfx_place_wet"
}
```

---

## 9. Customer System

### 9.1 Archetypes (cute, expressive, Lebaran fashion) [ASSUMPTION]
All archetypes are built from modular parts (body, head, hair or hijab, headwear, outfit, accessories) with color and motif variants.

| ID | Archetype | Typical outfit | Behavior modifiers | Available from |
|---|---|---|---|---|
| `kid_boy` | Child (boy) | Mini baju koko, peci | Patience ×0.9, orders 2–3 items, tip ×0.8 | L1 |
| `kid_girl` | Child (girl) | Mini gamis, hairband | Patience ×0.9, orders 2–3 items, tip ×0.8 | L1 |
| `teen` | Teenager | Batik shirt or tunic, sneakers | Patience ×0.85 (fast, impatient) | L1 |
| `adult_m` | Adult (man) | Baju koko, sarung, peci | Standard | L1 |
| `adult_f` | Adult (woman) | Gamis and hijab or kebaya | Standard | L1 |
| `parent` | Parent | Matching sarimbit outfit | Patience ×1.0, tip ×1.1 | L2 |
| `elder` | Elderly | Sarung, peci / kebaya and kerudung | Patience ×1.25, simpler orders (max 4 items), tip ×1.1 | L2 |
| `family` | Family of 3 (parents + child) at the counter | Sarimbit | One large order (5–7 items), patience ×1.2, tip ×1.3 | L3 |
| `vip` | Well-dressed guest | Elegant batik, accessories | Patience ×0.8, tip ×2.0 | L3 |

Eight base characters ship in MVP: `kid_boy`, `kid_girl`, `teen`, `adult_m`, `adult_f`, `parent`, `elder`, plus a combined `family` and `vip` using the same modular parts (total 9 archetypes, at least 12 distinct visual variants through color, headwear, and hair).

### 9.2 Personality and expressions
Each archetype has face states: neutral, happy, very happy, impatient, angry, and surprised. Big round eyes, small mouths, blush. Idle sounds are short non-verbal chirps (no speech, which avoids localization and voice work).

### 9.3 Customer state machine
```
SPAWNED -> WALKING_IN (1.0 s) -> ORDERING (bubble pop 0.8 s) -> WAITING
WAITING -> (served correct) -> HAPPY_REACT (0.6 s) -> PAYING (0.9 s) -> LEAVING_HAPPY -> REMOVED
WAITING -> (p <= 0.33) -> IMPATIENT (loop) -> (served correct) -> HAPPY_REACT ...
WAITING / IMPATIENT -> (p = 0) -> ANGRY_LEAVE (1.2 s) -> REMOVED  [counts as lost]
WAITING / IMPATIENT -> (served wrong) -> ANGRY_REACT (0.8 s) -> back to previous state with reduced patience
```
Slot at the counter is freed when the customer enters `LEAVING_*` so the spawner can add the next customer.

### 9.4 Patience calculation
```
patienceMax = level.basePatience
            + 4 * (itemCount - 2)                 // complexity bonus, in seconds, max +20
patienceMax *= archetype.patienceMult
patienceMax  = clamp(patienceMax, 18, 60)
```
Base patience: L1 = 40 s, L2 = 38 s, L3 = 34 s, L4 = 30 s.

### 9.5 Rewards and satisfaction
Satisfaction = the mood stage at serve time (Happy/Neutral/Impatient). It determines tip tier (section 11). Special archetype tip multipliers stack with tier tips.

### 9.6 Spawning logic (summary; details in F06 and section 10)
Seeded RNG (mulberry32). Interval = uniform(min, max) per level. Archetype chosen by level-weighted table. Rush waves spawn 3 customers within 4 seconds, respecting the active cap (extras wait for free slots).

### 9.7 Special customer behavior
- **VIP:** gold sparkle, leaves a larger tip, shorter patience; if served within 10 s grants a one-time `+Rp 5.000` bonus.
- **Family:** one customer group, one big order; served by a single plate with up to 7 items.
- (Post-MVP) **Food critic**, **Hungry rush**, **Kids with THR envelopes**.

Example JSON:
```json
{
  "id": "elder",
  "patienceMult": 1.25,
  "tipMult": 1.1,
  "maxItems": 4,
  "availableFrom": 2,
  "weights": { "1": 0, "2": 10, "3": 12, "4": 12 },
  "model": "char_elder",
  "voice": "sfx_chirp_low"
}
```

---

## 10. Level Progression and Difficulty Design

### 10.1 Level table [CONFIRMED names; numbers are ASSUMPTIONS tuned with a simulation bot]
| Level | Name | Shift (s) | Customers (total) | Max active | Spawn interval (s) | Base patience (s) | Ingredients | Items/order | Plates | Rush waves | Lost-customer limit |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Lebaran Pertama | 120 | 7 | 2 | 12–16 | 40 | 3 | 2 | 1 | 0 | 5 |
| 2 | Warung Mulai Ramai | 150 | 10 | 3 | 10–13 | 38 | 8 | 2–4 | 2 | 0 | 4 |
| 3 | Open House | 180 | 15 | 4 | 8–11 | 34 | 13 | 3–5 | 2 | 2 (at 40% and 75%) | 4 |
| 4 | Puncak Silaturahmi | 210 | 20 | 4 | 7–9 | 30 | 14 | 4–7 | 2 | 3 (at 30%, 55%, 80%) | 3 |

The last 15 seconds of every shift are the **closing phase** (no new customers).

### 10.2 Objectives, targets, and stars
Revenue targets use `target = round(0.55 x expectedMaxBase)` with expected averages from section 11.5. Revenue includes tips and combo bonuses.

| Level | Target for 1 star (completion) | 2 stars | 3 stars |
|---|---|---|---|
| 1 | Rp 65.000 | Rp 80.000 | Rp 98.000 |
| 2 | Rp 105.000 | Rp 135.000 | Rp 165.000 |
| 3 | Rp 180.000 | Rp 230.000 | Rp 280.000 |
| 4 | Rp 270.000 | Rp 340.000 | Rp 415.000 |

Star rules: 1 star = revenue ≥ target; 2 stars = revenue ≥ 2-star value; 3 stars = revenue ≥ 3-star value **and** lost customers ≤ 1. Each level subtracts one star (minimum 1 if completed) when mistakes ≥ 3.

### 10.3 Failure conditions
1. Lost customers exceed the level's limit → immediate **Game Over** screen.
2. The shift ends with revenue below the 1-star target → **Game Over** (retry available).
There is no lives system and no energy gating.

### 10.4 Difficulty scaling
Difficulty increases via: more ingredients and item counts, shorter patience, lower spawn intervals, higher active caps, rush waves, and special customers. Adjustments never drop below a floor: patience ≥ 18 s, spawn interval ≥ 6 s.

### 10.5 Level completion
Result screen: revenue vs target bars, stars, tips total, best combo, customers served and lost, mistakes, and buttons **Next level**, **Retry**, **Menu**. Next level unlocks at ≥ 1 star.

### 10.6 Level config example
```json
{
  "id": 3,
  "nameKey": "level.open_house",
  "shiftSeconds": 180,
  "closingSeconds": 15,
  "totalCustomers": 15,
  "maxActive": 4,
  "spawnInterval": [8, 11],
  "basePatience": 34,
  "unlocked": ["ketupat","lontong","opor_ayam","rendang","semur_daging","ayam_goreng",
               "sambal_goreng_kentang","telur_balado","sayur_labu_siam","perkedel",
               "bawang_goreng","kerupuk","sambal"],
  "itemCountWeights": { "3": 25, "4": 45, "5": 30 },
  "archetypeWeights": { "kid_boy":8,"kid_girl":8,"teen":10,"adult_m":14,"adult_f":14,"parent":10,"elder":8,"family":6,"vip":4 },
  "rushWaves": [ { "atRatio": 0.40, "count": 3 }, { "atRatio": 0.75, "count": 3 } ],
  "plates": 2,
  "lostLimit": 4,
  "targets": { "one": 180000, "two": 230000, "three": 280000 },
  "removeFeeRate": 0.25,
  "seedMode": "fixedPerAttempt"
}
```

---

## 11. Game Economy and Balancing

### 11.1 Payment formula
```
orderValue   = sum(ingredient.price)
tipRate      = 0.25 if p >= 0.66; 0.12 if 0.33 <= p < 0.66; 0.05 if p < 0.33     (p = patience ratio at serve)
perfectBonus = +0.10 to tipRate if the order had no removal and no wrong-serve
comboMult    = 1.0 (streak 0-1), 1.1 (2), 1.2 (3), 1.3 (4), 1.4 (5+)
tip          = orderValue * tipRate * archetype.tipMult
payment      = roundToNearest500( orderValue * comboMult + tip )
```
Combo streak = consecutive **correct** serves where each serve occurs within **12 seconds** of the previous. It resets on a wrong serve, a lost customer, or after 12 seconds without serving.

### 11.2 Penalties
| Event | Effect |
|---|---|
| Wrong serve | Patience −30% of max; combo resets; no cash loss |
| Customer leaves angry | −Rp 2.000 (reputation fee, revenue never below Rp 0), combo resets, counts toward lost limit |
| Removal/replacement of a placed ingredient | Level 1–2: free. Level 3+: fee = 25% of that ingredient's price (min Rp 250), also removes `perfectBonus` |

### 11.3 Bonuses and rewards
| Source | Reward |
|---|---|
| VIP served within 10 s | +Rp 5.000 |
| Level completion | Stars saved; "Tabungan" (savings) += Rp 5.000 per star (shown in menu; spendable post-MVP) |
| No lost customers in a level | +Rp 10.000 end-of-shift bonus (counts to revenue for stars) |

### 11.4 Tuning knobs (all in `data/economy.json`)
`tipTiers`, `comboWindowSeconds`, `comboMultipliers`, `leaveFee`, `removeFeeRate`, `waitPenaltyOnWrong`, `vipBonus`, `starTargets`.

### 11.5 Example calculations (for unit tests)
| Case | Inputs | Result |
|---|---|---|
| A. Ketupat + Rendang, p = 0.80, streak 0, perfect, adult_m | orderValue 18.000; tipRate 0.25 + 0.10 = 0.35; tip 6.300; comboMult 1.0 | payment = round500(18.000 + 6.300) = **Rp 24.500** |
| B. Order A from the brief (Ketupat 3.000 + Opor 12.000 + Sambal Goreng Kentang 5.000 + Bawang Goreng 1.000 = 21.000), p = 0.50, streak 3 (x1.2), not perfect | tip = 21.000 x 0.12 = 2.520; value x1.2 = 25.200 | payment = round500(27.720) = **Rp 27.500** |
| C. Order C (Lontong 2.500 + Opor 12.000 + Telur Balado 4.500 + Kerupuk 1.500 = 20.500), p = 0.20, VIP | tipRate 0.05; tip = 20.500 x 0.05 x 2.0 = 2.050 | payment = round500(20.500 + 2.050) = **Rp 22.500** |
| D. Customer leaves | −Rp 2.000 | revenue floor 0 |

Expected level potential (averages used for targets): L1 avg order ≈ Rp 16.500 x 7 = 115.500; L2 ≈ 19.500 x 10 = 195.000; L3 ≈ 22.000 x 15 = 330.000; L4 ≈ 24.500 x 20 = 490.000.

### 11.6 Balancing recommendations
1. Build a **simulation bot** (section 25) with three skill profiles (novice reaction 1.6 s/tap, average 1.0 s/tap, expert 0.6 s/tap). Targets: novice clears L1 ≥ 80%, L2 ≥ 55%, L3 ≥ 30%, L4 ≥ 10%; average clears L1 ≥ 95%, L2 ≥ 85%, L3 ≥ 65%, L4 ≥ 40%; expert 3-stars L4 ≥ 50%.
2. If novice clear rate on L1 < 80%, raise base patience by 4 s before changing prices.
3. Keep tips ≈ 15–25% of total revenue for an average player; if higher, reduce tip tiers.
4. Playtest 10 humans per level; adjust `waitPenaltyOnWrong` first if frustration appears.

---

## 12. UI/UX Specification

### 12.1 Principles
Rounded cards and buttons; consistent with the 3D art; strong hierarchy; readable typography; minimal decoration; clear action feedback; designed for thumbs. No emoji characters in UI (use SVG icons); no glassmorphism clutter; "toy sticker" feel with solid fills, soft outline, and subtle drop shadows. [ASSUMPTION]

### 12.2 Gameplay priorities (top to bottom of attention)
1) Customer orders. 2) Patience indicators. 3) Food assembly area. 4) Ingredient selection. 5) Serve action. 6) Money and level progress.

### 12.3 Typography and sizing
Display font: a rounded bold typeface (for example Baloo 2 or Fredoka) for numbers and titles; body: Nunito. Minimum body 14 px (mobile), button text 16 px. Tap targets ≥ 48 × 48 px (mobile). Font scaling follows `clamp()` with the stage width.

### 12.4 Screens

| Screen | Purpose and components |
|---|---|
| **Boot/Loading** | Logo, ketupat-weave progress ring, tip line, "Tap to start" (also unlocks audio) |
| **Main menu** | Title, big **Main** (Play) button, Level Select, Settings, savings and total stars, decorative stall scene with idle customers |
| **Level select** | 4 level cards (name, stars, best revenue, locked state with requirement), back |
| **Level intro** | Level name, objectives (target revenue, lost limit), new ingredients shown with icons, **Mulai** button |
| **Gameplay HUD** | Described in 12.5 |
| **Pause menu** | Resume, Restart, Settings (music, SFX), Quit to Menu (confirmation) |
| **Level complete** | Stars animation, revenue vs targets, tips, best combo, served/lost, mistakes, Next / Retry / Menu |
| **Game over** | Reason (too many lost customers, or target not met), summary, Retry (primary), Menu |
| **Settings** | Music volume + mute, SFX volume + mute, hints on/off, reduced motion, language (post-MVP) |

### 12.5 Gameplay HUD components
| Component | Content | Notes |
|---|---|---|
| Money pill | Rp total this shift with coin icon | Animated count-up on payment |
| Target bar | Progress to 1/2/3-star marks | Three tick marks on a bar |
| Timer | Remaining shift time (mm:ss) | Pulses in the last 15 s |
| Combo badge | "Kombo x3" with decay ring (12 s window) | Appears at streak ≥ 2 |
| Pause button | Top-right | 48 px |
| Order bubble | Item icons, patience bar with mood face | Per customer, near the customer |
| Plate area | Active plate(s), plate tabs, Serve and Clear buttons | Serve is primary-colored |
| Ingredient tray | Category tabs + icon buttons with price chips | Locked items dimmed |
| Toasts | "Tepat!", "Salah pesanan", "Pelanggan pergi" | 1.2 s, non-blocking |

### 12.6 Wireframes (textual)

**Portrait gameplay (mobile, 9:16 stage)**
```
+-----------------------------+  0%
| [Rp 45.500] [bar ▮▮▯] [1:12] [II] |  HUD (8%)
+-----------------------------+  8%
|  (3D stall, awning, lanterns)    |
|   [cust1]    [cust2]    [cust3]  |  Customers + bubbles (30%)
|   (bubble)   (bubble)   (bubble) |
+-----------------------------+ 38%
|        ===== counter =====       |
|   [Plate A]  [Plate B]           |  Prep counter (28%)
|   [Clear]       [  SERVE  ]      |
+-----------------------------+ 66%
| [Pokok][Lauk][Sayur][Pelengkap]  |
|  (SVG icons, 4 x 2 grid)         |  Ingredient tray (34%)
+-----------------------------+ 100%
```
**Landscape gameplay (desktop 16:9)**
```
+--------------------------------------------------------------+
| [Rp]  [target bar]   [Kombo]   [timer]            [pause][fs]|
+------------------+---------------------------+---------------+
| ORDER TICKETS    |      3D STALL SCENE       | INGREDIENT    |
| (cards with      |  customers + bubbles      | SHELVES       |
|  patience bars)  |  ---------------------    | (all 4        |
| cust1 ▮▮▮▯       |  [Plate A]   [Plate B]    |  categories,  |
| cust2 ▮▯▯▯       |  [Clear]     [ SERVE ]    |  grid, hotkeys|
| cust3 ▮▮▯▯       |                           |  1-9)         |
+------------------+---------------------------+---------------+
```

### 12.7 Feedback requirements
Every action has a visual, audio, and (where it helps) haptic response: placement squash + soft pop; wrong order red outline + shake + low buzz; correct order sparkle + coin burst + cheerful chime; impatience alert face + chime; leave sad whoosh. Haptics via `navigator.vibrate` (Android only, optional, default on, can be disabled). [ASSUMPTION]

---

## 13. Mobile and Desktop Responsive Design

### 13.1 Mobile (portrait only) [CONFIRMED]
- The game stage is **portrait 9:16 preferred**; actual stage supports 9:16 down to 9:21 and up to 3:4 by flexing the ingredient tray height, never by changing the layout type.
- Safe areas respected (`env(safe-area-inset-*)`, `viewport-fit=cover`). No horizontal scroll (`overflow: hidden`, `touch-action: none` on the canvas).
- Thumb zone: Serve and the ingredient tray are in the bottom 40%.
- **Orientation enforcement strategy** (research-based): the Screen Orientation `lock()` API is not supported on iOS Safari and, where supported, generally requires fullscreen or an installed app. [VERIFIED] Therefore:
  1. Declare `"orientation": "portrait"` in the web app manifest (applies when installed as a PWA).
  2. Try `screen.orientation.lock('portrait')` after the first user gesture (and after fullscreen when the user opts in). Failures are ignored silently.
  3. Fallback (always on): if the viewport becomes landscape on a touch device, **do not build a landscape layout**. Keep the portrait stage fitted to viewport height and centered with decorative side bars, and show a non-blocking hint "Putar ponsel ke posisi tegak untuk pengalaman terbaik" for 3 seconds (dismissible; shown once per session).
- Touch device detection: `(pointer: coarse) and (hover: none)`; not by user agent alone.

### 13.2 Desktop (landscape)
- Layout shown in 12.6. Uses the full viewport; 3D canvas covers the screen; DOM panels (tickets, shelves) float over it with fixed widths (clamped) so they never stretch on ultrawide monitors.
- Mouse: click, drag, right-click remove; keyboard shortcuts (1–9, Space, Backspace, C, Tab, Esc, P, F for fullscreen).
- Minimum supported desktop viewport: 1024 × 600.

### 13.3 Shared rules
Same gameplay, same data, same art identity. The `ResponsiveLayout` module computes a layout profile (`portrait` or `landscape`) from touch-device detection and viewport aspect; layout profile changes at runtime never reset game state (resize and orientation events are debounced 100 ms). Pixel ratio capped at 2 (desktop) and 1.5 (mobile).

### 13.4 Verification viewports
Mobile portrait: 360×640, 390×844, 412×915, 430×932. Mobile landscape fallback check: 844×390. Tablet portrait: 768×1024. Desktop: 1024×600, 1366×768, 1920×1080, 2560×1080.

---

## 14. 3D Art Direction

### 14.1 Style
Cute, polished, appetizing, toy-like soft 3D. Rounded forms, gentle bevels, soft highlights, subtle ambient occlusion baked into vertex colors, warm light. Cozy and festive but uncluttered; not overly childish.

### 14.2 Palette [CONFIRMED families; hex values are assumptions]
| Role | Color |
|---|---|
| Warm cream (backgrounds, plates) | `#FFF4DA` |
| Emerald green (ketupat, UI accent, awning) | `#1F8A5B` / deep `#14664A` |
| Soft yellow (highlights, coins) | `#FFD966` |
| Warm orange (warm light accents) | `#F28C28` |
| Light brown (wood, counter) | `#C8935B` |
| Festive accents | Magenta `#D9437B`, teal `#2BB3B1`, gold `#E0B040` |
| UI outlines | `#4A2B17` |

### 14.3 Food
Each ingredient is a **separate asset**. Appetizing rules: saturated but natural colors, glossy sauces using `MeshPhysicalMaterial` (clearcoat for curries/sambal), matte for rice cakes and fried items, subtle steam particles on hot dishes (opor, rendang, ayam goreng), bump maps for crispy textures. The ketupat weave texture and the creamy opor yellow are the signature pieces; they must be reviewed first (see art review gates in section 25).

### 14.4 Characters
Chibi proportions (head about 45% of body height), simple limbs, expressive faces (eyes, brows, mouth swapped per expression), cloth with Lebaran motifs (songket-like trim, batik patterns drawn with canvas textures). Variants through a **modular builder**: body base × head × hair/hijab × headwear × outfit × accessory.

### 14.5 Environment
A cozy warung: wood counter, green-striped awning, hanging ketupat ornaments (3D woven diamonds), paper lanterns with warm glow, banners with Islamic geometric patterns (eight-pointed star tessellation), a rice cooker/dandang, a rack of ketupat, tabletop condiments, a cash box, and a soft-focus kampung street background (bamboo fence, banana leaves, evening sky). Warm key light (golden hour), cool fill; the 3D background remains subdued so food stays the focus.

### 14.6 Style guardrails
No gore, no alcohol, no pork, no religious texts rendered as decoration. Geometric patterns are decorative only (not calligraphy). Customer designs are diverse and respectful.

---

## 15. 3D Asset Inventory

### 15.1 Pipeline decision [ASSUMPTION; OQ-3]
| Option | Pros | Cons | Verdict |
|---|---|---|---|
| **Procedural builders in code** (Three.js primitives + extrude + canvas textures) | Zero file size, full control, consistent style, instantly tweakable by AI agents (proven in prior projects) | Needs careful visual iteration | **MVP default** |
| Hand-modeled GLB in Blender | Best quality | Needs a human artist | Roadmap |
| AI image-to-3D (Tripo, Meshy, etc.) | Fast drafts | License and topology risk; inconsistent style | Only with owner approval |
| CC0 libraries (Kenney Food Kit 200+ models incl. glTF; Quaternius food packs; KayKit Restaurant Bits 140+ kitchen/food assets; Poly Pizza mixed licenses) | Legal, quick props | Western-centric foods; style mismatch with Lebaran dishes (verify) | Use for generic **props** (cups, pots, crates) after license check |

An `AssetRegistry` resolves `food_<id>`: if `/assets/models/food/food_<id>.glb` exists it is loaded; otherwise the procedural builder is used. This allows GLB upgrades with no code change.

### 15.2 Budgets (recommended)
Food: ≤ 1.5k triangles each, one material, ≤ 512 px textures. Plate and props: ≤ 1k. Characters: ≤ 5k triangles, ≤ 2 materials. Stall environment total: ≤ 35k triangles. Visible scene total ≤ 120k triangles; ≤ 120 draw calls on mobile (≤ 250 desktop). Textures: ≤ 1024 px on mobile; compress with KTX2/WebP for GLB assets. Initial downloadable assets ≤ 3 MB (excluding the Three.js bundle).

### 15.3 Inventory

**A. Food ingredients (14)**
| Asset ID | Description | Variations | Animation | Format | Modeled |
|---|---|---|---|---|---|
| `food_ketupat` | Woven diamond rice cake, cut slices | whole icon version | pop-in, squash | procedural / GLB | 3D |
| `food_lontong` | Banana-leaf wrapped rice rounds | — | pop-in | procedural / GLB | 3D |
| `food_opor_ayam` | Creamy yellow chicken curry in small bowl | — | steam, pop | procedural / GLB | 3D |
| `food_rendang` | Dark glossy beef | — | steam, pop | procedural / GLB | 3D |
| `food_semur_daging` | Sweet soy beef with potato | — | steam, pop | procedural / GLB | 3D |
| `food_ayam_goreng` | Fried chicken pieces | — | pop | procedural / GLB | 3D |
| `food_sambal_goreng_kentang` | Red-orange potato | — | pop | procedural / GLB | 3D |
| `food_sayur_labu_siam` | Chayote in light broth | — | steam, pop | procedural / GLB | 3D |
| `food_telur_balado` | Egg with red balado | — | pop | procedural / GLB | 3D |
| `food_perkedel` | Golden potato patties | — | pop | procedural / GLB | 3D |
| `food_bawang_goreng` | Fried shallot pile | scatter variants | sprinkle particles | procedural | 3D |
| `food_kerupuk` | Round cracker | — | pop | procedural / GLB | 3D |
| `food_sambal` | Red sambal dollop | — | squish | procedural | 3D |
| `food_emping` | Emping chips | — | pop | procedural | 3D |

**B. Serving plates and containers**
| Asset ID | Description | Variations | Animation | Format | Modeled |
|---|---|---|---|---|---|
| `plate_main` | Cream round plate with green rim motif | 3 rim colors (cosmetic, post-MVP) | slide-to-customer, shake, return | procedural | 3D |
| `plate_ghost` | Outline plate for drag target | — | pulse | procedural | 3D |
| `bowl_small` | Small bowl for curries | — | — | procedural | 3D |
| `leaf_liner` | Banana-leaf liner | — | — | procedural | 3D |

**C. Customers (9 archetypes, 12+ variants)**
`char_kid_boy`, `char_kid_girl`, `char_teen`, `char_adult_m`, `char_adult_f`, `char_parent`, `char_elder`, `char_family`, `char_vip`. Variations: skin tones, outfit colors and motifs, headwear. Animations: idle, walk-in, order-think, happy, very-happy, impatient, angry, leave, pay. Format: procedural modular builder (GLB later). Budget ≤ 5k triangles each.

**D. Environment and background**
`env_stall_counter`, `env_stall_awning`, `env_lantern`, `env_ketupat_ornament`, `env_banner_geometric`, `env_kampung_background`, `env_ground`, `env_props_misc` (pots, rack, cash box, condiment jars). Animations: lanterns and ornaments sway, subtle light flicker. Format: procedural; kampung background as layered 3D cards.

**E. Kitchen equipment**
`kit_rice_pot`, `kit_wok`, `kit_serving_tray`, `kit_ketupat_rack`, `kit_serve_bell`. Mostly decorative and for ambience (steam, simmering); no gameplay interaction in MVP.

**F. UI elements (SVG/PNG/WebP, not 3D)**
Icons for all 14 ingredients (`ui_icon_food_<id>.svg` or 3D-rendered thumbnails), coin, star, timer, combo, mood faces (4), pause, play, restart, home, trash, speaker/music, fullscreen. Buttons, cards, bars are CSS. Fonts: Baloo 2 and Nunito (WOFF2).

**G. Effects and particles**
`fx_coin_burst`, `fx_sparkle`, `fx_steam`, `fx_sprinkle`, `fx_heart`, `fx_sweat`, `fx_angry_puff`, `fx_star_burst`, `fx_dust_puff`. Implemented as pooled instanced sprites/meshes.

**H. Animations (see section 16)**

### 15.4 Naming conventions
`<category>_<name>[_<variant>]` in snake_case. Prefixes: `food_`, `plate_`, `char_`, `env_`, `kit_`, `ui_`, `fx_`, `sfx_`, `music_`. Files: `food_opor_ayam.glb`, `ui_icon_coin.svg`, `sfx_order_new.mp3`. IDs in JSON match asset IDs exactly.

---

## 16. Animation Specification

All animations use delta time and easing; none rely on frame count. Durations in seconds.

| Target | Animation | Duration | Easing / notes |
|---|---|---|---|
| Ingredient placement | Fly parabola from button to slot, land squash (scale 1.0 → 0.85 → 1.0) | 0.25 + 0.15 | ease-out-back |
| Ingredient removal | Scale to 0 with upward hop | 0.18 | ease-in |
| Plate to customer | Slide + slight arc | 0.35 | ease-in-out |
| Plate rejected | Return slide + shake | 0.4 | damped shake |
| Customer walk-in | Walk bob and slide to counter | 1.0 | linear + bob |
| Order bubble pop | Scale 0 → 1.15 → 1.0 | 0.3 | ease-out-back |
| Patience bar | Smooth drain; color shift green → yellow → red | continuous | color tween |
| Impatient | Face swap, sweat drop, small head shake loop | loop 0.8 | — |
| Happy | Face swap, hop, hearts/sparkles | 0.6 | spring |
| Pay | Coins burst to money pill; count-up | 0.9 | ease-out |
| Leave happy | Wave and walk out | 1.0 | — |
| Leave angry | Stomp and walk out | 1.2 | — |
| Rush wave | Soft bell + camera nudge | 0.6 | — |
| Combo badge | Pulse on increment, ring decays over 12 s | — | — |
| Level complete | Stars pop sequentially, confetti | 1.5 | spring |
| Ambient | Lantern sway, ketupat ornament swing, steam | loop | sine |

`prefers-reduced-motion`: disable camera nudges, confetti, shakes; shorten others by 40%.

---

## 17. Audio and Music Specification [CONFIRMED mandatory]

### 17.1 Background music
- Mood: cheerful, festive, lighthearted, relaxing, Indonesian festive character; seamless loop of 60–90 seconds; ~100–112 BPM; major pentatonic or diatonic melodies.
- Instrumentation: marimba/kolintang-style mallet melody, soft kendang-style percussion, gentle shaker, light acoustic guitar or ukulele chords, occasional bedug accent and bell chimes (respectful, short).
- **Cultural guardrail:** do not use takbir recitations, Qur'an recitation, or other religious chants as music or SFX; do not use copyrighted songs (including well-known Lebaran songs) without a license. Original composition only. [CONFIRMED: no unlicensed commercial songs]
- Dynamic behavior: music ducks to 50% on pause and on result stinger; light intensity layer (extra percussion) fades in during rush waves.
- Production (OQ-2): MVP uses an in-browser **procedural sequencer** (Web Audio oscillators/FM to emulate mallet and percussion) with pre-defined patterns; the music module also accepts a file `music_lebaran_loop_01.mp3` to replace it without code changes.

### 17.2 Sound effects
| Event | ID | Character |
|---|---|---|
| Customer arrival | `sfx_customer_arrive` | Soft shop bell |
| Order notification | `sfx_order_new` | Two-note pop |
| Ingredient selection | `sfx_select` | Light tick |
| Food placement | `sfx_place_soft` / `sfx_place_wet` | Soft thud / gentle splat (varies by category) |
| Successful order | `sfx_order_ok` | Cheerful chime |
| Wrong order | `sfx_order_wrong` | Short low "bonk" |
| Customer impatient | `sfx_impatient` | Soft rising warble |
| Customer leaving | `sfx_leave` | Descending whoosh |
| Payment and coin | `sfx_coin` | Coin jingle (pitch rises with combo) |
| Combo up | `sfx_combo` | Ascending sparkle |
| Rush wave | `sfx_rush` | Bedug + bell hit |
| Level complete | `sfx_level_complete` | Short fanfare stinger |
| Game over | `sfx_game_over` | Gentle sad stinger |
| Button interactions | `sfx_ui_click`, `sfx_ui_back` | Soft click |
| Countdown | `sfx_tick`, `sfx_go` | Beeps |

### 17.3 Behavior and controls
- Independent **Music volume/mute** and **SFX volume/mute**; settings persist in `localStorage`.
- Audio is created and unlocked on the first user gesture (browser autoplay policies); a "Tap to start" screen provides it.
- Music loops without gaps (schedule next loop ahead of time in the sequencer; for files use `AudioBufferSourceNode` with `loop = true` or a dual-buffer crossfade).
- SFX use a small pool; at most 8 concurrent voices; rapid repeats vary pitch ±5%.
- Pause on `visibilitychange` (hidden) and resume on return; mute respects OS silent mode where detectable.
- Formats: MP3 (universal baseline) with optional OGG; SFX ≤ 60 KB each; total audio ≤ 1.5 MB (file mode). [ASSUMPTION: confirm OGG support on target Safari versions during implementation.]
- Naming: `music_<theme>_<name>_<nn>.mp3`, `sfx_<event>[_<variant>].mp3`.

---

## 18. Technical Stack Evaluation

### 18.1 Comparison
| Option | Strengths | Limitations | Fit |
|---|---|---|---|
| **Three.js (vanilla, TypeScript)** | Smallest footprint (about 168 kB min+gzip for one release, versus about 1.4 MB for Babylon.js in one published comparison [VERIFIED, version-specific]); largest ecosystem; full control of the render loop; easy for AI agents to reason about; procedural modeling is straightforward; proven in this team's previous games | You build game structure yourself (state, UI, audio) | **Recommended** |
| React Three Fiber (R3F) | Declarative scene; React ecosystem | Adds React reconciliation to a per-frame game; one developer reported slowdowns only when excessive React renders occurred [anecdotal]; extra abstraction for fast-changing game state | Not chosen |
| Babylon.js | Full game engine features (GUI, physics, inspector); modular imports | Larger bundle; more engine surface than this 2.5D-style game needs | Backup option |
| PlayCanvas | Strong mobile performance focus and editor (third-party claim) | Cloud editor workflow, ECS, harder for repo-based AI-agent flow | Not chosen |
| Phaser (+3D assets) | Excellent 2D UI/game framework | 3D food and characters would need pre-rendered sprites, conflicting with the required 3D asset approach | Not chosen |
| Unity/Godot web export | Rich tooling | Heavy web builds, weaker mobile web loading and DOM integration [ASSUMPTION] | Not chosen |

### 18.2 Recommended stack
| Layer | Choice | Reason |
|---|---|---|
| Language/build | **TypeScript + Vite** | Types for data models, fast dev server, tree-shaking. Pin Three.js to the latest stable release at project start (use exact version in `package.json`). |
| Rendering | **Three.js, WebGLRenderer** | Widest mobile compatibility; WebGPU optional later |
| HUD/menus | **DOM + CSS** (rounded stickers, SVG icons) | Accessible, crisp text, native touch targets, easy responsive layout |
| State | **Zustand (vanilla store)** + small typed EventBus | Predictable, framework-free state; testable |
| Tweens | Small in-house tween utility (or GSAP if approved) | Keep bundle small |
| Audio | In-house `AudioManager` on **Web Audio API** | Procedural music and SFX, optional file mode |
| Tests | **Vitest** (unit), **Playwright** (e2e, screenshots) | Headless verification by AI agents |
| i18n | JSON dictionaries (`id.json`) | English later |

Estimated initial JS budget: ≤ 400 kB gzip (Three.js plus game code). [ASSUMPTION]

---

## 19. Technical Architecture

### 19.1 Modules and responsibilities
| Module | Responsibility |
|---|---|
| `core/Game` | Owns the main loop (`requestAnimationFrame`, dt clamp 50 ms), fixed-step logic at 60 Hz, and orchestrates systems |
| `core/StateMachine` | App and level state machines (19.3) |
| `core/Store` | Zustand store: level state, plates, customers, economy, settings |
| `core/EventBus` | Typed events (19.7) decoupling gameplay, UI, audio, and FX |
| `gameplay/orders` | `OrderGenerator`, `OrderValidator` |
| `gameplay/customers` | `CustomerSpawner`, `CustomerController` (state machine, patience) |
| `gameplay/assembly` | `PlateModel`, slot rules, add/remove/replace |
| `gameplay/economy` | `EconomyService` (payment, tips, combo, fees, stars) |
| `gameplay/levels` | `LevelRunner` (phases, timer, rush waves, win/lose), `Progress` (save/load) |
| `render/SceneManager` | Renderer, scene, lights, quality tiers |
| `render/CameraRig` | Camera framing per layout using `setViewOffset` so 3D content is centered in the free area not covered by DOM panels |
| `render/AssetRegistry` | Resolves `food_*`, `char_*`, `env_*`: GLB if present, else procedural builder; caches geometry/materials; lazy loading |
| `render/builders/*` | Procedural food, character, and environment builders |
| `render/fx/*` | Pooled particles (coins, sparkles, steam, sprinkles) |
| `input/*` | Pointer events (unified touch/mouse), drag controller, keyboard map |
| `ui/*` | DOM components and screens, bound to the store |
| `audio/*` | `AudioManager`, `MusicSequencer`, `SfxSynth`, file loader |
| `layout/ResponsiveLayout` | Layout profile (portrait/landscape), safe areas, orientation hint |

### 19.2 Rendering architecture
- One `WebGLRenderer` canvas fills the viewport. Perspective camera (FOV about 32 degrees) looking at the stall front from slightly above (about 18 degrees pitch).
- **Safe frame:** content is framed in the area not covered by DOM panels: portrait = top 66% of the height; desktop = center region between the ticket and shelf panels. `camera.setViewOffset` shifts the projection so no layout change alters world scale.
- Lighting: one warm directional key, hemisphere fill, small warm point lights at lanterns (maximum 3, cheap). Shadows: shadow map only on High tier; blob shadows elsewhere.
- Picking: Three.js `Raycaster` against plate slot colliders and placed items for tap-to-remove; DOM handles ingredient buttons and drag ghosts.

### 19.3 State machines
**App state**
```
BOOT -> LOADING -> TAP_TO_START -> MAIN_MENU
MAIN_MENU -> LEVEL_SELECT | SETTINGS
LEVEL_SELECT -> LEVEL_INTRO -> (PLAYING)
PLAYING <-> PAUSED
PLAYING -> LEVEL_COMPLETE | GAME_OVER
LEVEL_COMPLETE -> LEVEL_INTRO(next) | MAIN_MENU
GAME_OVER -> LEVEL_INTRO(retry) | MAIN_MENU
```
**Level phases (inside PLAYING):** `COUNTDOWN (3 s)` → `RUNNING` → `CLOSING (last 15 s, no new spawns)` → `ENDED` (evaluate win/lose after the last customer leaves or the shift timer expires + 10 s grace).

**Plate state:** `EMPTY` → `BUILDING` → `READY_TO_SERVE` (has ≥ 2 items) → `SERVING (in flight)` → `EMPTY` (correct) or `BUILDING` (returned).

**Order lifecycle:** `CREATED` → `DISPLAYED` → `IN_PROGRESS` (any plate matches partially) → `SERVED_CORRECT` | `EXPIRED`. Wrong serves keep the order in `IN_PROGRESS` with `mistakes += 1`.

### 19.4 Game loop and timing
Logic timers use accumulated delta time (not wall time); pause freezes the accumulator. Rendering interpolates. Tab hidden → auto-pause. dt clamp prevents jumps after tab restore.

### 19.5 Data models (TypeScript sketch)
```ts
type SlotId = 'carb' | 'main' | 'side' | 'topping' | 'sauce' | 'crunch';

interface Ingredient { id: string; slot: SlotId; price: number; unlockLevel: number;
  weight: number; nameKey: string; asset: { model: string; icon: string }; sfx: string; }

interface Order { id: string; items: string[]; value: number; createdAt: number; mistakes: number; removals: number; }

interface Customer { id: string; archetype: string; order: Order; patienceMax: number; patience: number;
  state: CustomerState; seat: number; tipMult: number; }

interface Plate { id: 'A' | 'B'; items: Record<SlotId, string[]>; state: PlateState; removalsThisPlate: number; }

interface LevelState { id: number; phase: 'COUNTDOWN'|'RUNNING'|'CLOSING'|'ENDED'; timeLeft: number;
  revenue: number; tipsTotal: number; served: number; lost: number; mistakes: number;
  streak: number; lastServeAt: number; bestCombo: number; }

interface SaveData { version: 1; stars: Record<number, 0|1|2|3>; bestRevenue: Record<number, number>;
  savings: number; settings: Settings; tutorialDone: boolean; }

interface Settings { musicVolume: number; sfxVolume: number; musicMuted: boolean; sfxMuted: boolean;
  hints: boolean; reducedMotion: boolean; haptics: boolean; language: 'id'|'en'; }
```
Save example:
```json
{ "version": 1, "stars": { "1": 3, "2": 1 }, "bestRevenue": { "1": 104500, "2": 118000 },
  "savings": 20000, "tutorialDone": true,
  "settings": { "musicVolume": 0.6, "sfxVolume": 0.8, "musicMuted": false, "sfxMuted": false,
                "hints": true, "reducedMotion": false, "haptics": true, "language": "id" } }
```

### 19.6 Key algorithms
**Order generation:** pick archetype by weights → pick itemCount by level weights → choose `carb` (weights) → `main` (weights) → remaining slots with probability: side 0–2 per itemCount, topping 35%, sauce 25%, crunch 30% (until itemCount reached) → ensure not identical to the previous order → compute value.
**Validation:** set comparison (7.4).
**Spawner:** timer + active cap + rush waves; seeded RNG.
**Economy:** section 11 formulas as pure functions (no side effects) for easy unit testing.

### 19.7 Event catalog (EventBus)
`customer:arrived`, `customer:ordered`, `customer:impatient`, `customer:left` (reason: happy|angry), `plate:itemAdded`, `plate:itemRemoved`, `plate:cleared`, `order:served` (result: correct|wrong, detail), `economy:payment`, `economy:combo`, `level:phase`, `level:complete`, `level:failed`, `ui:pause`, `audio:duck`. Systems communicate via events; UI and audio never mutate gameplay state directly.

### 19.8 Asset loading
Boot loads only the shared core (UI fonts, procedural registry, plates, stall). Level-specific content (extra ingredients, archetypes) is built lazily when a level is selected and cached. GLB loader (optional) supports Meshopt and KTX2 decoders; compression guidance: meshopt for fast decoding, KTX2 for textures; note that geometry compression does not improve frame rate by itself. [VERIFIED]

### 19.9 Responsive viewport handling
`ResponsiveLayout` listens to `resize`, `orientationchange`, and `visualViewport` changes (debounced 100 ms), recomputes: layout profile, stage rect, DPR cap, safe areas, camera view offset. State never resets on layout changes.

---

## 20. Project Directory Structure

```text
ketupat-rush/
├── index.html
├── package.json
├── vite.config.ts
├── tsconfig.json
├── public/
│   ├── manifest.webmanifest          # orientation: portrait (PWA)
│   ├── assets/
│   │   ├── models/                   # optional GLB overrides (same IDs as procedural)
│   │   │   ├── food/  characters/  environment/  kitchen/
│   │   ├── textures/                 # optional compressed textures
│   │   ├── audio/
│   │   │   ├── music/                # optional file mode (music_*.mp3)
│   │   │   └── sfx/                  # optional file mode (sfx_*.mp3)
│   │   ├── fonts/                    # Baloo 2, Nunito (woff2)
│   │   └── ui/                       # SVG icons
├── src/
│   ├── main.ts                       # bootstrap
│   ├── core/                         # Game.ts, StateMachine.ts, Store.ts, EventBus.ts, Rng.ts, Tween.ts
│   ├── data/                         # ingredients.json, archetypes.json, levels.json, economy.json, i18n/id.json
│   ├── gameplay/
│   │   ├── customers/                # CustomerSpawner.ts, CustomerController.ts
│   │   ├── orders/                   # OrderGenerator.ts, OrderValidator.ts
│   │   ├── assembly/                 # PlateModel.ts, slots.ts
│   │   ├── economy/                  # EconomyService.ts
│   │   └── levels/                   # LevelRunner.ts, Progress.ts
│   ├── render/
│   │   ├── SceneManager.ts  CameraRig.ts  Lighting.ts  AssetRegistry.ts
│   │   ├── builders/                 # food/*.ts, characters/*.ts, environment/*.ts, plates.ts
│   │   └── fx/                       # particles, steam, sprinkles
│   ├── input/                        # PointerInput.ts, DragController.ts, Keyboard.ts
│   ├── ui/                           # Hud.ts, OrderTicket.ts, IngredientTray.ts, screens/*, styles/*.css
│   ├── layout/                       # ResponsiveLayout.ts, OrientationHint.ts
│   ├── audio/                        # AudioManager.ts, MusicSequencer.ts, SfxSynth.ts
│   └── utils/
├── tests/
│   ├── unit/                         # validator, economy, spawner, order generator, patience
│   ├── simulation/                   # bot player balance runs
│   └── e2e/                          # Playwright viewports and flows
├── tools/                            # preview pages (?preview=food, ?preview=characters), asset checks
└── docs/                             # PRD.md, ASSETS.md, BALANCE.md, CHANGELOG.md
```

**Justification:** `data/` keeps all tunable content outside code; `gameplay/` is pure logic without Three.js imports (unit-testable in Node); `render/` is the only module touching Three.js; `ui/` binds DOM to the store; `audio/` is isolated for autoplay and volume rules; `tools/` provides visual review pages for AI agents; `public/assets` supports optional GLB overrides without code changes.

---

## 21. Performance Requirements

| Area | Requirement |
|---|---|
| Frame rate | Desktop 60 FPS; mid-range Android and modern iPhones 60 FPS target, 30 FPS floor |
| Devices | Modern desktop browsers (Chrome, Edge, Firefox, Safari); mid-range Android (roughly 4 GB RAM, mid GPU); iPhone with Safari 16+ |
| Quality tiers | **High** (desktop): DPR ≤ 2, soft shadow map 1024. **Medium** (modern phones): DPR ≤ 1.5, blob shadows. **Low**: DPR 1, particles ≤ 30, Lambert materials. Auto-select by device hints, then downgrade if average FPS < 40 over 5 s |
| 3D optimization | Budgets in 15.2; instancing for repeated items (sprinkles, ornaments); share geometry/materials; merge static environment meshes; `matrixAutoUpdate = false` for static objects |
| Textures | ≤ 1024 px on mobile; generated canvas textures cached and shared; KTX2/WebP for file assets |
| Lazy loading | Level-specific assets built on demand; audio file mode streams after the first interaction |
| Memory | ≤ 250 MB on mobile; dispose geometries/materials/textures of removed objects; no per-frame allocations in loops |
| Draw calls | ≤ 120 mobile, ≤ 250 desktop |
| Touch responsiveness | Pointer events, `touch-action: none` on canvas; input-to-feedback latency ≤ 100 ms |
| Loading | Loading screen with progress; interactive ≤ 3 s on a fast connection, ≤ 8 s on a slow 4G; no layout shift after load |
| Battery | Cap to 60 FPS; reduce to 30 FPS on Low tier and when the tab is not focused |

Compression note: Draco and Meshopt reduce file size but do not improve FPS; reduce triangles and draw calls to improve FPS. [VERIFIED]

---

## 22. Functional Requirements (Consolidated)

Priority: P0 = MVP-blocking, P1 = MVP-important, P2 = nice-to-have.

| ID | Area | Requirement | Priority |
|---|---|---|---|
| FR-001 | Platform | Runs in modern desktop and mobile browsers without installation | P0 |
| FR-002 | Layout | Mobile always uses portrait layout; landscape never triggers a different layout (13.1) | P0 |
| FR-003 | Layout | Desktop uses a landscape three-column layout (13.2) | P0 |
| FR-010–013 | Orders | Order bubbles per F01 | P0 |
| FR-020–024 | Ingredients | Tap/drag placement per F02 | P0 |
| FR-030–033 | Plate | Removal and clearing per F03 | P0 |
| FR-040–043 | Serving | Exact set validation and soft failure per F04 | P0 |
| FR-050–052 | Customers | Lifecycle, patience, leave per F05 | P0 |
| FR-060–064 | Spawner | Seeded spawn with caps and rush per F06 | P0 |
| FR-070–074 | Economy | Payment, tips, combo, fees, stars per F07 | P0 |
| FR-080–082 | Levels | Four levels with targets and unlock flow per F08 | P0 |
| FR-090–092 | Responsive | Layout profiles and state-safe resize per F09 | P0 |
| FR-100–102 | Audio | Music and SFX with separate controls per F10 | P0 |
| FR-110–112 | Settings | Persisted settings and progress per F11 | P0 |
| FR-120–122 | Onboarding | Level 1 contextual hints per F12 | P1 |
| FR-130–132 | Loading | Loading screen and lazy assets per F13 | P0 |
| FR-140–142 | Pause | Pause, restart, quit per F14 | P0 |
| FR-150 | Food | All 14 ingredients exist as separate 3D assets with the visual specs in 8.1 | P0 |
| FR-151 | Customers | At least 9 archetypes and 12 visual variants | P1 |
| FR-152 | Art | Environment includes ketupat ornaments, lanterns, geometric motifs | P0 |
| FR-153 | FX | Coin, sparkle, steam, sprinkle effects | P1 |
| FR-160 | Fullscreen | Desktop fullscreen toggle (button and `F`); hidden when unsupported | P1 |
| FR-161 | Haptics | Optional vibration on Android | P2 |
| FR-162 | Hints | Wrong-serve mismatch hints on the plate | P0 |
| FR-170 | Quality | Auto quality downgrade when FPS < 40 for 5 s | P1 |

---

## 23. Non-Functional Requirements

| Category | Requirement |
|---|---|
| Performance | Section 21 targets |
| Usability | New players complete the first order within 30 seconds without reading text; all primary actions reachable with one thumb on a 390 px wide screen |
| Compatibility | Last two major versions of Chrome, Edge, Firefox, Safari; Safari iOS 16+; Chrome Android |
| Accessibility | Tap targets ≥ 48 px; contrast ≥ 4.5:1 for text; patience shown by color **and** icon/shape; reduced-motion setting; keyboard operable on desktop; ARIA labels on DOM controls; no flashing above 3 Hz |
| Reliability | No crash on resize, tab switch, or rapid input; localStorage failures handled |
| Security/privacy | No accounts, no tracking, no third-party network calls at runtime |
| Maintainability | Gameplay modules free of Three.js imports; all tunables in JSON; ESLint + TypeScript strict; files < 400 lines where practical |
| Localization | UI strings in `i18n/id.json`; no hard-coded text |
| Legal | CC0/own assets only; license file `docs/ASSETS.md` lists all third-party assets |

---

## 24. Acceptance Criteria (Overall)

| ID | Criterion (testable) |
|---|---|
| AC-01 | A full shift of Level 1 can be played from menu to results with no console errors |
| AC-02 | Order validation: 100 scripted cases (exact, missing, extra, duplicates, order of placement) return the expected result |
| AC-03 | Payment calculations match the four examples in 11.5 exactly |
| AC-04 | Patience drains only while PLAYING and not while paused |
| AC-05 | Spawner never exceeds `maxActive`, never spawns in the closing phase, and is deterministic for a given seed |
| AC-06 | At 360×640, 390×844, 412×915, 430×932: no horizontal scroll, the ingredient tray and Serve button fully visible, tap targets ≥ 48 px |
| AC-07 | At 844×390 (mobile landscape fallback): portrait stage fitted by height, no landscape layout, hint shown once |
| AC-08 | At 1366×768 and 1920×1080: three-column layout, canvas fills the viewport, no stretched panels |
| AC-09 | Resizing or rotating during play does not change money, timers, plates, or customers |
| AC-10 | Music and SFX volumes and mutes work independently and persist after reload |
| AC-11 | Audio starts only after the first user gesture; no autoplay errors in the console |
| AC-12 | All 14 ingredients render as distinct 3D assets that match the colors in 8.1 within ±35 per RGB channel (measured at the preview page) and are recognizable in screenshots |
| AC-13 | Wrong serve: patience −30% of max, mismatch hints shown, plate returned, combo reset |
| AC-14 | Customer leaving: revenue −Rp 2.000 (floor 0), combo reset, lost counter increments, game over at the limit |
| AC-15 | 20 consecutive Game Over → Retry cycles leave no leaked objects (renderer info memory stable ±5%) and no console errors |
| AC-16 | Desktop average ≥ 55 FPS and mid-range Android ≥ 30 FPS during the busiest moment of Level 4 (measured by the FPS tool) |
| AC-17 | Initial load: interactive ≤ 3 s on fast connection; JS ≤ 400 kB gzip |
| AC-18 | No emoji characters in UI strings and no religious recitations in audio |
| AC-19 | Simulation bot results fall within the target clear-rate ranges in 11.6 |
| AC-20 | Keyboard-only play is possible on desktop (select customer, add ingredients, serve, pause) |

---

## 25. Testing Strategy

### 25.1 Unit tests (Vitest, Node, no rendering)
`OrderValidator`, `EconomyService` (all formulas and rounding), `PatienceCalculator`, `OrderGenerator` (constraints, no consecutive duplicates), `CustomerSpawner` (cap, closing, rush, seed determinism), `PlateModel` (replace/remove rules), `Progress` (save/load/migrations).

### 25.2 Simulation tests
A deterministic **bot** plays levels using only game APIs with profiles novice/average/expert (reaction time per tap). Runs 200 seeds per level and reports clear rate, average stars, tip share, and lost customers. Results must match 11.6 targets. Used to tune `data/levels.json` and `data/economy.json` (not code).

### 25.3 End-to-end (Playwright)
Flows: menu → level 1 → serve → results; pause/resume; restart; settings persistence; viewport matrix (13.4); orientation/resize during play; keyboard-only run; audio unlock flow. Take screenshots for every screen at each viewport.

### 25.4 Visual verification protocol for AI coding agents (important)
Lessons from previous projects: visual claims must be backed by evidence, not assumed.
1. Every asset builder has a preview page (`?preview=food`, `?preview=characters`, `?preview=stall`) showing the asset from three angles with color swatches of the target hex values.
2. Agents must **compare screenshots to the target color and shape spec** and report measured RGB deltas; no "looks good" without numbers.
3. **Art review gates:** (a) ketupat + opor ayam + rendang approved first, (b) plate with a full 7-item dish at gameplay camera scale, (c) 9 customers lineup, (d) complete stall. Each gate needs owner approval before the next.
4. Detail must be readable at gameplay size (a food item is about 60–90 px wide on a phone); verify in gameplay screenshots, not only in preview.
5. When an approach fails twice, report the blocker instead of repeating the same fix.

### 25.5 Performance and device testing
FPS and memory overlay (`?debug=1`); renderer `info` (draw calls, triangles) logged; test matrix: one low-end Android, one mid-range Android, one iPhone, one laptop, one desktop 1080p; throttled CPU 4x in Chrome DevTools as a proxy.

### 25.6 Audio, accessibility, and UX checks
Autoplay and unlock behavior on iOS Safari and Android Chrome; volume persistence; reduced motion; contrast checks; screen-reader labels on DOM controls; playtests (5–10 users per level) measuring first-order time, clear rate, and frustration notes.

---

## 26. MVP Scope

### 26.1 In scope
- Four levels with all 14 ingredients and unlock flow.
- Core loop: order bubbles, plate assembly (tap and drag), serving, wrong-serve soft failure, patience, tips, combos, stars.
- 9 customer archetypes (12+ visual variants) with 6 expressions each.
- Procedural 3D food, plate, characters, and the stall environment with Lebaran decoration.
- Mobile portrait and desktop landscape layouts; orientation fallback; fullscreen on desktop.
- Music (procedural loop) and the full SFX set; independent controls.
- Loading, menu, level select, intro, pause, results, game over, settings.
- Level 1 contextual hints; localStorage persistence.
- Unit tests, simulation bot, Playwright smoke and viewport tests.

### 26.2 Out of scope for MVP
Stall upgrade shop, cosmetics, daily challenges, leaderboards, accounts, multiplayer, English UI, endless mode, real-money items, ads.

### 26.3 Implementation priorities (phases)
| Phase | Deliverable | Gate |
|---|---|---|
| P0 | Project skeleton, data JSON, pure gameplay logic + unit tests | AC-02, AC-03, AC-05 pass |
| P1 | Scene, camera rig, layout profiles, stall placeholder, plate | Screenshots at all viewports (AC-06 to AC-08) |
| P2 | Food builders (ketupat, opor, rendang first) + preview page | Art gate (a), AC-12 for 3 items |
| P3 | Playable loop with 1 archetype, HUD, tap/drag, serving, economy, Level 1 | AC-01, AC-13, AC-14 |
| P4 | Remaining food, all archetypes and expressions, Levels 2–4, rush waves, VIP/family | Art gates (b)(c), AC-12 full |
| P5 | Audio system and content, settings, persistence, onboarding | AC-10, AC-11 |
| P6 | Polish: FX, animation, stall detail, quality tiers, performance, e2e, bot balancing | AC-15 to AC-20 |

---

## 27. Future Development Roadmap

1. Stall upgrade shop (patience boosters, extra plate, tip boosters) funded by "Tabungan".
2. Cosmetic plates, awnings, and decorations.
3. More dishes (Lemang, Kolak, Nastar-style cookies as dessert slot) and regional variants (Padang, Jawa, Betawi).
4. More special customers (food critic, hungry rush, kids with THR envelopes).
5. Daily challenges and an endless "Open House" mode.
6. English and regional languages; voice-less localized text.
7. Optional online leaderboard (privacy-reviewed).
8. PWA installation with offline play; GLB art upgrade by a 3D artist.
9. Seasonal events beyond Lebaran (Ramadan buka puasa mode).

---

## 28. Risks and Technical Considerations

| ID | Risk | Likelihood / Impact | Mitigation |
|---|---|---|---|
| R1 | Procedural food or characters look crude, not appetizing | High / High | Art gates, preview pages with measured color checks, small number of signature assets first, allow GLB override |
| R2 | Mobile performance (draw calls, overdraw) | Med / High | Budgets (15.2), quality tiers, instancing, blob shadows, FPS auto-downgrade |
| R3 | Portrait enforcement not possible on iOS | High / Med | Fallback strategy 13.1; PWA manifest; hint, not blocking |
| R4 | Drag-and-drop accuracy on small phones | Med / Med | Tap-to-add as the primary interaction; large targets; drag is secondary |
| R5 | Audio autoplay and iOS silent mode | High / Med | Tap-to-start unlock; mute toggle; test on iOS |
| R6 | Balancing too hard or too easy | Med / Med | Simulation bot; all numbers in JSON; playtests |
| R7 | Scope creep (many assets and 28-section PRD) | Med / High | Strict MVP scope, phase gates |
| R8 | Cultural sensitivity (religious sounds, attire, symbols) | Low / High | Guardrails in 14.6 and 17.1; review by Indonesian stakeholders |
| R9 | Licensing of any third-party assets or music | Low / High | CC0 only; `docs/ASSETS.md` registry; no unlicensed songs |
| R10 | AI agents claim success without evidence | Med / High | Verification protocol 25.4; numeric acceptance criteria |
| R11 | Browser differences (WebGL context loss, Safari memory limits) | Med / Med | Handle `webglcontextlost`; dispose resources; test on Safari |
| R12 | Three.js API changes between releases | Low / Med | Pin exact version; upgrade deliberately |

---

## Appendix A. Naming Conventions

| Type | Pattern | Example |
|---|---|---|
| 3D assets | `<category>_<name>[_<variant>]` | `food_opor_ayam`, `char_adult_f`, `env_lantern` |
| UI icons | `ui_icon_<name>.svg` | `ui_icon_coin.svg`, `ui_icon_food_rendang.svg` |
| Audio | `sfx_<event>[_<variant>]`, `music_<theme>_<name>_<nn>` | `sfx_order_ok`, `music_lebaran_loop_01` |
| Data IDs | snake_case, identical to asset IDs without prefix | `opor_ayam` |
| i18n keys | `<area>.<name>` | `food.opor_ayam`, `ui.serve`, `level.open_house` |
| TS files | PascalCase for classes, camelCase for utilities | `PlateModel.ts`, `rng.ts` |

## Appendix B. Sample Indonesian UI Strings (`id.json`)
```json
{
  "ui.play": "Main", "ui.serve": "Sajikan", "ui.clear": "Kosongkan", "ui.pause": "Jeda",
  "ui.resume": "Lanjut", "ui.retry": "Coba Lagi", "ui.next": "Lanjut ke Level Berikutnya",
  "ui.menu": "Menu", "ui.tap_to_start": "Ketuk untuk mulai",
  "toast.correct": "Tepat!", "toast.wrong": "Pesanan belum sesuai", "toast.left": "Pelanggan pergi",
  "hint.rotate": "Putar ponsel ke posisi tegak untuk pengalaman terbaik",
  "level.1": "Lebaran Pertama", "level.2": "Warung Mulai Ramai",
  "level.3": "Open House", "level.4": "Puncak Silaturahmi",
  "result.revenue": "Pendapatan", "result.target": "Target", "result.tips": "Tip", "result.combo": "Kombo Terbaik"
}
```

## Appendix C. Instructions for AI Coding Agents (Definition of Done)
1. Read this PRD fully before coding; do not change [CONFIRMED] items; log any decision on [OPEN] items in `docs/DECISIONS.md`.
2. Build in phases (26.3). Do not start a phase before the previous gate passes.
3. Keep gameplay logic free of Three.js; put tunables in JSON.
4. Verify visually with the protocol in 25.4 and attach screenshots and numeric results to each phase report.
5. No emoji in UI text, comments, or code. No unlicensed assets or music.
6. Never mark a requirement done without a passing test or a measurable check from section 24.
7. At the end of each phase, report: what changed, evidence, known issues, next steps.

## Appendix D. Glossary
*Warung*: small food stall. *Ketupat/Lontong*: compressed rice cakes (woven palm-leaf or banana-leaf wrapped). *Opor Ayam*: chicken in coconut-milk curry. *Rendang*: slow-cooked spiced beef. *Semur*: sweet soy braise. *Balado*: chili sambal coating. *Perkedel*: fried potato patty. *Kerupuk/Emping*: crackers/chips. *Sambal*: chili paste. *Open House*: Lebaran visiting tradition. *Silaturahmi*: maintaining kinship and friendship. *THR*: Lebaran holiday bonus, often given as envelopes. *Sarimbit*: matching family outfits. *Peci*: cap. *Gamis*: long dress.
