# PRD — Menara Kue
### Susun Kue, Raih Skor Tertinggi!

| | |
|---|---|
| **Versi** | 2.0 (rombak total, menggantikan semua versi sebelumnya) |
| **Tanggal** | 18 November 2026 |
| **Produk** | Mini-game pada microsite Mudik Lebaran |
| **Platform** | Web desktop/laptop (fullscreen) dan mobile web |
| **Tech stack** | HTML, CSS, JavaScript vanilla + Three.js r149 (disimpan lokal), tanpa build tool, tanpa backend |

**Catatan perombakan.** Versi sebelumnya gagal pada empat hal: (1) area bermain hanya kolom sempit di tengah layar sehingga tidak terasa fullscreen di laptop, (2) kue terlalu besar sampai melewati batas area dan menutupi skor, (3) seluruh kue tampil pucat dan seragam sehingga tidak terbaca sebagai kue, dan (4) bidang hitam kosong di bawah nampan. Versi ini mengatur ulang tata letak, skala kamera, warna, dan cara pemotongan kue, serta mewajibkan verifikasi visual yang terukur.

---

## 1. Product Overview

Menara Kue adalah game kasual *precision stacking*. Pemain menjatuhkan kue Lebaran 3D yang bergerak horizontal ke atas tumpukan kue sebelumnya dengan satu ketukan. Bagian kue yang tidak bertumpu terpotong dan jatuh, sehingga tumpukan makin sempit. Game berakhir saat kue sama sekali tidak menumpu. Tujuannya membangun menara setinggi mungkin dan memecahkan skor tertinggi.

## 2. Objectives

1. Dipahami dalam kurang dari 5 detik, tanpa tutorial.
2. Tampil fullscreen yang memenuhi seluruh layar laptop maupun ponsel, dengan suasana Lebaran malam yang hidup.
3. Kue 3D yang lucu, berwarna cerah, dan mudah dibedakan satu sama lain.
4. Mendorong main ulang lewat skor tertinggi, perfect stack, dan kombo.
5. Lancar: 60 FPS desktop, minimal 30 FPS di HP kelas menengah.

## 3. Target Users

Pengunjung umum segala usia pada microsite Mudik Lebaran, di laptop maupun ponsel, dengan sesi singkat 1–3 menit. Tanpa akun, tanpa instalasi.

## 4. Game Specifications

| Parameter | Nilai |
|---|---|
| Genre / mekanik | Casual arcade / precision stacking |
| Kontrol | Tap, klik, Spasi, Enter |
| Mode | Endless |
| Tampilan | **Fullscreen penuh** pada semua ukuran layar. Tidak ada bingkai portrait atau bar kosong di kiri-kanan |
| Area bermain | Kolom tengah selebar `fieldPx = min(0,96 × lebar layar, 0,72 × tinggi layar)`. Latar 3D memenuhi seluruh layar |
| Fullscreen API | Tombol dan tombol `F` untuk masuk/keluar fullscreen browser (disembunyikan bila tidak didukung) |
| Penyimpanan | `localStorage`, kunci `menarakue.highscore` |

Contoh `fieldPx`: laptop 1366×768 → 553 px; monitor 1920×1080 → 777 px; ponsel 390×844 → 374 px.

## 5. User Flow

1. Pengguna membuka game dan melihat Initial Screen (latar 3D penuh layar).
2. Menekan **Main**.
3. Fondasi tampil di atas nampan, kue pertama mulai bergerak.
4. Pengguna mengetuk untuk menjatuhkan kue, sistem menghitung overlap, memotong, memperbarui skor.
5. Kecepatan naik bertahap.
6. Gagal menumpu → Game Over, menampilkan skor akhir dan skor tertinggi.
7. **Main Lagi** atau **Menu Utama**.

## 6. Gameplay Flow

```
MENU --Main--> READY (fondasi, 0,4 detik)
READY --> MOVING (kue bergerak ping-pong)
MOVING --tap--> DROPPING (≤ 140 ms)
DROPPING --overlap > 0 dan lebar ≥ MIN_WIDTH--> STACKED --> MOVING
DROPPING --tidak ada overlap atau lebar < MIN_WIDTH--> FALLING (0,8 detik) --> GAME_OVER
GAME_OVER --Main Lagi--> READY
GAME_OVER --Menu Utama--> MENU
```

Ketukan saat `DROPPING`, `STACKED`, `FALLING` diabaikan. Game dijeda otomatis saat tab tidak aktif dan dilanjutkan dengan satu ketukan.

## 7. Game Mechanics

### 7.1 Koordinat
Logika memakai koordinat ternormalisasi: lebar area bermain = 1,0. Lapisan render memetakan ke dunia 3D: `FIELD_UNITS = 10` unit, sehingga `xDunia = (x − 0,5) × 10`. Perubahan ukuran layar hanya memengaruhi kamera, bukan state.

### 7.2 Pergerakan Kue
- Ping-pong horizontal pada jalur di atas tumpukan, kecepatan konstan, memantul di tepi area bermain dengan margin 0,02.
- Kue berikutnya mulai dari sisi berlawanan dari arah sebelumnya.
- Kue baru mulai bergerak ≤ 250 ms setelah kue sebelumnya selesai ditumpuk (dibawa oleh capit mesin derek 3D dari atas).
- Kue yang bergerak selalu berada sepenuhnya di dalam layar dan tidak pernah menutupi skor.

### 7.3 Menjatuhkan Kue
Ketukan menghentikan gerak horizontal dan memulai animasi jatuh ≤ 140 ms (ease-in) ke puncak tumpukan. Hanya satu ketukan dihitung per kue.

### 7.4 Overlap dan Pemotongan
Dengan permukaan kue baru [aL, aR] dan puncak tumpukan [bL, bR]:

```
overlapL = max(aL, bL); overlapR = min(aR, bR); overlapW = overlapR − overlapL
```

- `overlapW ≤ 0` → game over.
- `|pusatA − pusatB| ≤ PERFECT_TOL` → perfect stack (7.5), tanpa pemotongan.
- Selain itu → bagian di luar [overlapL, overlapR] terpotong dan jatuh sebagai objek terpisah. Bagian tersisa menjadi permukaan baru.
- `overlapW < MIN_WIDTH` → game over setelah potongan ditampilkan.

### 7.5 Perfect Stack dan Kombo
- `PERFECT_TOL = 0,015` (1,5% lebar area bermain).
- Perfect: posisi dikunci sejajar, lebar tidak berkurang, cincin cahaya, taburan meises, teks "Sempurna!".
- Kombo = jumlah perfect berturut-turut, kembali ke 0 saat kue terpotong.
- Pemulihan lebar (default aktif, dapat dimatikan): perfect dengan kombo ≥ 3 menambah lebar `REGROW = 0,03`, maksimum `BASE_WIDTH`.

### 7.6 Kesulitan Progresif
```
speed(n) = min(SPEED_MAX, SPEED_START + n × SPEED_STEP)   (satuan: lebar area per detik)
```

| Parameter | Nilai |
|---|---|
| `SPEED_START` | 0,55 |
| `SPEED_STEP` | 0,03 per kue |
| `SPEED_MAX` | 1,60 |
| `BASE_WIDTH` | 0,56 |
| `MIN_WIDTH` | 0,12 |
| `PERFECT_TOL` | 0,015 |
| `REGROW` | 0,03 |

### 7.7 Kamera (Rumus Skala, Wajib Diikuti)
Tujuan: lebar area bermain selalu persis `fieldPx` piksel, di layar mana pun.

```
pxPerUnit          = fieldPx / FIELD_UNITS
visibleHeightUnits = tinggiLayarPx / pxPerUnit
jarakKamera        = visibleHeightUnits / (2 × tan(FOV/2))      (FOV = 35 derajat)
```

- Kamera perspektif, pitch ±20 derajat dari depan-atas, mengarah ke titik `yPuncakMenara + (0,58 − 0,5) × visibleHeightUnits` sehingga puncak menara berada sekitar 58% tinggi layar dari atas.
- Jalur kue yang bergerak berada ±0,26 × visibleHeightUnits di atas puncak menara.
- Kamera mengikuti puncak menara dengan lerp halus (±250 ms). Dihitung ulang saat ukuran layar berubah.
- Lebar kue fondasi di layar = `BASE_WIDTH × fieldPx` (±3%).

## 8. Object Shape dan Stacking Mechanism

### 8.1 Dua Komponen per Kue
| Komponen | Fungsi |
|---|---|
| Model 3D | Bodi kue + topping yang tampil ke pemain |
| Stacking Surface | Interval horizontal [kiri, kanan] tak terlihat untuk menghitung overlap |

### 8.2 Membangun Bodi Kue (Pemotongan Tanpa Clipping Plane)
Setiap kue punya **outline tampak atas** berupa poligon (elips, persegi membulat, bunga N cuping, bergerigi N cuping, atau bulan sabit), diskalakan ke lebar permukaan yang dibutuhkan. Bodi dibuat dengan `ExtrudeGeometry` dari outline tersebut dengan bevel besar (tampak empuk dan membulat).

Pemotongan:
1. Poligon outline dipotong (Sutherland–Hodgman) terhadap jendela X [x0, x1]. Sisi yang tidak terpotong tidak dibatasi (tepi membulat aslinya tetap utuh).
2. Poligon hasil di-extrude menjadi bodi baru. Bidang potong otomatis rata dan padat, tanpa lubang dan tanpa penutup tambahan.
3. Potongan yang jatuh dibuat dari poligon komplementer dengan cara yang sama.
4. Topping yang titik pusatnya berada di luar jendela dipindahkan ke objek potongan; yang di dalam tetap pada kue.

Dilarang memakai `clippingPlanes` dan dilarang memakai skala sumbu X sebagai pengganti pemotongan.

### 8.3 Aturan Stacking Surface
1. Lebar surface = lebar bodi (bounding box outline) × `SURFACE_RATIO` (default 0,92).
2. Surface tidak terlihat (kecuali `?debug=1`).
3. Posisi visual selalu mengikuti pusat surface.
4. Kue berikutnya dibangun dengan lebar = lebar surface tersisa (seluruh dimensi diskalakan seragam), tidak pernah lebih kecil dari `MIN_WIDTH`.
5. Tinggi lapisan = tinggi bodi kue sebenarnya; kue ditumpuk tepat di atas permukaan atas lapisan sebelumnya.
6. Lapisan yang berada lebih dari 10 lapis di bawah layar dibuang (geometri di-dispose), data skor tetap.

### 8.4 Fondasi
Kue fondasi berukuran `BASE_WIDTH` di tengah, berdiri di atas nampan 3D (cakram hijau dengan cincin torus emas) di atas meja kayu. Meja dan taplak memenuhi bagian bawah layar. Tidak boleh ada area hitam kosong. Fondasi tidak menambah skor.

## 9. Functional Requirements

| ID | Feature | Description | Priority | Acceptance Criteria |
|---|---|---|---|---|
| FR-01 | Memulai permainan | Tombol Main memulai game | P0 | Main menampilkan Gameplay Screen dalam < 500 ms; fondasi tampil; kue pertama bergerak |
| FR-02 | Pergerakan objek | Kue bergerak ping-pong dengan kecepatan sesuai skor | P0 | Gerak halus; kecepatan sama pada 60 dan 120 Hz (delta time); kue tak pernah keluar layar |
| FR-03 | Mekanisme stacking | Ketukan menjatuhkan kue ke puncak | P0 | Satu ketukan = satu kue; animasi ≤ 140 ms; ketukan saat animasi diabaikan |
| FR-04 | Perhitungan overlap | Overlap dari interval stacking surface | P0 | 20 kasus uji cocok dengan hitungan manual (galat < 0,001) |
| FR-05 | Pemotongan objek | Poligon dipotong dan di-extrude ulang | P0 | Bidang potong rata dan padat, tanpa lubang atau artefak; potongan jatuh dan memudar; sisi tak terpotong tetap membulat |
| FR-06 | Sistem scoring | +1 per kue, bonus perfect dan kombo | P0 | Skor sesuai rumus bagian 12 pada 10 skenario |
| FR-07 | Perfect stack | Penyelarasan dalam toleransi dikunci | P0 | Selisih ≤ 0,015 → snap, tanpa potongan, "Sempurna!", cincin cahaya |
| FR-08 | Combo system | Bonus perfect berturut-turut | P1 | Indikator kombo naik tiap perfect dan reset saat terpotong |
| FR-09 | Progressive difficulty | Kecepatan naik sampai batas | P0 | Sesuai rumus 7.6 pada kue ke-1, 10, 35, 60; tidak melebihi `SPEED_MAX` |
| FR-10 | Game over | Overlap ≤ 0 atau lebar < `MIN_WIDTH` | P0 | Game Over Screen muncul ≤ 1 detik setelah kegagalan |
| FR-11 | Restart game | Main Lagi dan Menu Utama | P0 | State bersih penuh (skor, kombo, kecepatan, lapisan, potongan, partikel, kamera); 20 kali restart berturut-turut tanpa bug atau galat konsol |
| FR-12 | Skor tertinggi | `localStorage` | P0 | Bertahan setelah refresh; tanpa storage game tetap berjalan |
| FR-13 | **Layout fullscreen** | Canvas 3D memenuhi seluruh viewport | P0 | Pada 1366×768, 1920×1080, 390×844, 768×1024: canvas = ukuran layar, tanpa bar kosong; lebar area bermain = `fieldPx` (±2%); saat jendela diubah ukurannya, state dan skor tidak berubah |
| FR-14 | **Tombol fullscreen** | Fullscreen API | P0 | Tombol dan tombol `F` masuk/keluar fullscreen; ikon berubah sesuai status; tersembunyi bila API tidak didukung |
| FR-15 | Skala kue | Ukuran kue sesuai rumus kamera | P0 | Lebar kue fondasi di layar = 0,56 × `fieldPx` (±3%); kue yang bergerak selalu penuh di dalam layar dan tidak menyentuh HUD |
| FR-16 | **Keterbacaan warna** | Setiap kue berwarna cerah dan berbeda | P0 | Pada `?preview=1`, warna rata-rata permukaan atas tiap kue berada dalam ±35 per kanal RGB dari warna target; tidak ada kue pucat kehabisan warna (overexposed) |
| FR-17 | Variasi kue | 8 kue (Fase 1), 15 kue (Fase 2) | P0 | Tidak ada dua kue sama berturut-turut; semua jenis muncul dalam 30 kue pertama (Fase 1) |
| FR-18 | Input ganda | Mouse, sentuh, keyboard | P0 | Tap, klik, Spasi, Enter menjatuhkan kue; satu sentuhan tidak memicu dua aksi |
| FR-19 | Jeda otomatis | Saat tab tidak aktif | P1 | Gerak berhenti; lanjut setelah satu ketukan |
| FR-20 | Feedback visual | Mendarat, perfect, potongan, game over | P1 | Squash singkat ≤ 150 ms; `prefers-reduced-motion` mematikan getaran |
| FR-21 | Efek suara (opsional) | Web Audio, tombol bisu | P2 | Aktif setelah interaksi pertama; preferensi tersimpan |

## 10. Non-Functional Requirements

| Aspek | Kebutuhan |
|---|---|
| Performance | 60 FPS desktop, ≥ 30 FPS HP menengah. Delta time (maks. 50 ms), satu loop `requestAnimationFrame`, pixel ratio maks. 2, cache material dan geometri statis, pooling partikel, dispose lapisan lama, `castShadow` hanya pada beberapa lapisan teratas |
| Usability | Tanpa tutorial; petunjuk satu kalimat; seluruh layar area ketuk; skor besar dan kontras tinggi |
| Compatibility | Dua versi mayor terbaru Chrome, Edge, Firefox, Safari (iOS 15+), Chrome Android; berjalan dari `file://` maupun server statis |
| Responsiveness | Canvas selalu sebesar viewport; kamera dihitung dari rumus 7.7; safe area (`viewport-fit=cover`); `touch-action: none` |
| Maintainability | Semua parameter di `config.js`; modul terpisah; komentar singkat pada logika stacking dan pemotongan |
| Accessibility | Dapat dimainkan dengan keyboard; `aria-label` pada tombol; kontras teks ≥ 4,5:1; `prefers-reduced-motion`; perfect juga ditandai teks, bukan hanya warna |

## 11. UI Components dan Screen Specifications

**Gaya UI:** "stiker": blok warna solid, outline gelap 3 px, bayangan offset keras tanpa blur, sudut membulat; font Fredoka dan Nunito dengan fallback. Ikon SVG inline. **Tanpa emoji.** Tanpa glassmorphism.

### A. Initial Screen
Latar 3D penuh layar dengan menara kue contoh yang bergoyang pelan. Judul "Menara Kue", tagline "Susun Kue, Raih Skor Tertinggi!", tombol **Main**, petunjuk "Ketuk untuk menjatuhkan kue. Susun tepat agar menara makin tinggi.", dan "Rekor: N" (disembunyikan bila belum ada).

### B. Gameplay Screen
HUD menempel pada tepi layar penuh, bukan pada kolom area bermain:
- Tengah atas: skor besar, indikator kombo ("Kombo x3", tampil bila ≥ 2).
- Kiri atas: chip "Rekor".
- Kanan atas: tombol suara, jeda, dan fullscreen (SVG).
- Teks "Sempurna!" muncul singkat di dekat tumpukan.
HUD tidak menutupi jalur gerak kue.

### C. Game Over Screen
Panel "Game Over", skor akhir, skor tertinggi, penanda "Rekor Baru!", tombol **Main Lagi** dan **Menu Utama**. Panel masuk dengan animasi memantul ≤ 400 ms di atas tumpukan yang tetap terlihat.

## 12. Scoring System

```
poinKue = 1 + (perfect ? min(kombo, 5) : 0)
```

Kombo dihitung termasuk kue saat ini. Kue biasa = 1; perfect pertama = 2; perfect berturut-turut ke-2, 3, 4, 5+ = 3, 4, 5, 6 (maksimum 6). Kue gagal = 0 dan game over. Skor tertinggi diperbarui dan disimpan saat game over; "Rekor Baru!" hanya bila skor akhir melebihi rekor sebelumnya.

## 13. Edge Cases

| Kondisi | Penanganan |
|---|---|
| Tanpa overlap | Game over; kue jatuh melewati tumpukan, lalu Game Over Screen |
| Overlap sangat kecil | `overlapW < MIN_WIDTH` → game over setelah potongan tampil; selain itu lanjut |
| Perfect stack | Snap, tanpa potongan, kombo naik, lebar mungkin pulih `REGROW` |
| Kecepatan maksimum | Tertahan di `SPEED_MAX` |
| Ketukan beruntun | Hanya yang pertama per kue dihitung |
| Refresh | Kembali ke Initial Screen; rekor tetap |
| Ukuran layar atau mode fullscreen berubah | Kamera dan skala dihitung ulang; state tidak berubah |
| Rekor baru | Disimpan, ditandai, dan tampil di menu berikutnya |
| `localStorage` tak tersedia | try/catch; rekor hanya selama sesi |
| Tab tidak aktif | Dijeda; delta time dibatasi |
| Menara sangat tinggi | Lapisan jauh di bawah layar dibuang |
| Sentuhan lalu klik sintetis | Hanya satu aksi |
| Fullscreen API tidak didukung (misalnya iPhone) | Tombol disembunyikan; game tetap memenuhi viewport |

## 14. Acceptance Criteria (Keseluruhan)

- Game dapat dimainkan dari Initial Screen sampai Game Over dan kembali tanpa galat konsol.
- Semua FR P0 dan P1 lulus.
- Canvas memenuhi seluruh layar di 1366×768, 1920×1080, 390×844, 768×1024, tanpa bar kosong dan tanpa area hitam; tombol fullscreen berfungsi di desktop.
- Skala sesuai rumus 7.7 (kue fondasi = 0,56 × `fieldPx`), kue tidak pernah menutupi skor atau keluar layar.
- Tiap kue berwarna cerah sesuai target dan terbaca sebagai jenis kue yang berbeda; tidak ada kue pucat seragam.
- Pemotongan menghasilkan bidang potong padat tanpa lubang pada 20 kali pemotongan acak.
- Simulasi: overlap benar pada 1.000 kasus acak, kecepatan ≤ `SPEED_MAX`, lebar tak pernah negatif atau melebihi `BASE_WIDTH`.
- 20 siklus Game Over → Main Lagi menghasilkan state awal identik.
- Tanpa emoji di UI, teks, dan kode. Rekor bertahan setelah muat ulang.

## 15. Technical Constraints

- Three.js r149 lokal di `js/lib/three.min.js` (salin dari proyek Mudik Lebaran Dash), JavaScript vanilla, tanpa build tool, tanpa Python, tanpa berkas gambar kue.
- Seluruh model kue dibuat prosedural dari poligon outline + `ExtrudeGeometry` + bentuk dasar untuk topping.
- Semua parameter di `config.js`.

---

## Lampiran A. Model Kue 3D

Acuan bentuk dan warna: gambar di `referensi/` (Koleksi Kue Manis Pastel). Tidak perlu mirip persis; yang penting siluet, warna, dan topping khas tiap kue terbaca jelas dan gayanya konsisten lucu.

**Aturan umum:** bevel besar agar empuk, `MeshStandardMaterial` roughness 0,5–0,6 untuk adonan, `MeshPhysicalMaterial` dengan clearcoat hanya untuk glasir dan selai, warna jenuh dan cerah, tanpa putih murni. Topping dengan posisi acak berbasis seed. Dimensi sebagai rasio terhadap lebar bodi (W).

### Fase 1 (kerjakan dan verifikasi dulu: 8 kue)
| ID | Kue | Outline | Kedalaman | Tinggi | Warna bodi | Topping |
|---|---|---|---|---|---|---|
| c01 | Nastar keju | Elips | 0,85 W | 0,55 W (kubah) | `#F2A93B` mengilap | 10 kapsul tipis `#FFD34D` |
| c02 | Kastengel | Persegi membulat | 0,50 W | 0,42 W (2 lapis) | `#E8B04A` bawah, `#F5A623` atas | 12 kapsul tipis keju `#FFD34D` |
| c03 | Semprit bunga | Bunga 8 cuping | 0,90 W | 0,40 W | `#FFD966` | Bola ceri `#E53935` mengilap |
| c04 | Kue meises | Elips | 0,85 W | 0,50 W | `#C98A4B` | 16 kapsul cokelat `#4A2B17` |
| c05 | Choc chip | Elips | 0,90 W | 0,38 W | `#D9A25E` | 6 bongkah `#5B3420` |
| c06 | Kue almond | Persegi membulat | 0,50 W | 0,40 W | `#F0B24D` | 7 irisan almond `#F7E1B5` miring |
| c07 | Nastar tart | Bergerigi 14 cuping | 0,90 W | 0,42 W | `#F1B45A` | Kubah selai `#FF9A1F` mengilap |
| c08 | Sandwich cokelat | Elips | 0,85 W | 0,50 W (3 lapis) | Cokelat `#6B3A22`, krim `#F7E3A8` | 7 kubus kecil kacang `#F7D774` |

### Fase 2 (setelah Fase 1 lolos verifikasi: 7 kue)
| ID | Kue | Outline | Warna dan topping |
|---|---|---|---|
| c09 | Putri salju | Bulan sabit | `#FBF6EA` matte, remah bola kecil |
| c10 | Semprit pilin | Elips 3 tingkat | `#FFD966`, biji pistachio `#7DBB3F` |
| c11 | Sagu keju | Persegi membulat | `#F3C25A`, parutan keju |
| c12 | Nastar bulat | Elips kubah | `#FFA81F` clearcoat, daun `#4FA36B` |
| c13 | Semprit pandan | Bunga 6 cuping | `#9FD25A`, bola krim `#FFF4DA` |
| c14 | Kotak zigzag cokelat | Persegi membulat | `#F0B24D`, 5 kapsul cokelat zigzag |
| c15 | Kue kacang | Elips | `#E8B04A`, 12 remah kacang `#FFD36B` |

## Lampiran B. Arah Visual dan Pencahayaan

- **Gaya:** 3D kartun lucu, hangat, mengilap, selaras dengan Mudik Lebaran Dash.
- **Palet:** hijau ketupat `#2E9E6B`, hijau tua `#1F6B52`, kuning `#FFD34D`, krem `#FFF4DA`, cokelat `#4A2B17`, oranye `#FF9A3C`. Cerah, tidak pucat.
- **Render:** `WebGLRenderer` antialias, output sRGB, `ACESFilmicToneMapping` dengan **exposure ≤ 1,0**, shadow map PCFSoft, pixel ratio maks. 2.
- **Cahaya (mencegah warna pucat):** `HemisphereLight` (langit `#BFD8FF`, tanah `#6B4A2B`, intensitas ≤ 0,55); `DirectionalLight` hangat `#FFE2B8` intensitas ≤ 0,9 dari kiri-atas-depan, mengikuti puncak menara; tanpa ambient tambahan. Jika warna kue tampak lebih pucat dari target, turunkan intensitas, bukan menambah cahaya.
- **Latar 3D penuh layar (malam Lebaran):** gradasi hijau tua ke senja oranye di dasar; bulan sabit 3D sungguhan (ExtrudeGeometry bentuk sabit, emissive hangat, halo lembut); bintang (Points) berkelip; lampion dan ketupat 3D menggantung yang bergoyang pelan; siluet masjid low-poly di horizon sepanjang lebar layar; meja kayu dan taplak yang memenuhi dasar layar. Parallax lebih lambat dari kamera.
- **Tahap latar (P1):** skor 0–14 senja, 15–34 malam bertabur bintang, 35+ fajar Idulfitri; transisi halus.
- **Dilarang:** emoji, gradasi ungu-biru generik, glassmorphism, area hitam kosong.

## Lampiran C. Struktur Berkas dan Rencana

```
index.html
css/style.css
js/
├── lib/three.min.js   # r149, salin dari Mudik Lebaran Dash
├── config.js          # seluruh parameter
├── geometry.js        # outline poligon, pemotongan Sutherland–Hodgman, ExtrudeGeometry
├── cookies3d.js       # buatKue(id, lebar, jendelaX), topping menempel presisi, material
├── claw3d.js          # capit mesin derek 3D (rel kuningan, kereta, kabel baja, kepala capit 4 lengan)
├── scene.js           # renderer, kamera (rumus 7.7), lampu, latar 3D, nampan
├── game.js            # state machine, stacking, skor, kesulitan, resetGame()
├── input.js           # tap, klik, keyboard
├── ui.js              # HUD, menu, game over, fullscreen
└── main.js            # inisialisasi, loop, resize, ?preview=claw, ?preview=side, ?test=1
referensi/
PRD-Menara-Kue.md
README.md
```

| Tahap | Cakupan |
|---|---|
| 1 | Renderer fullscreen, kamera berbasis rumus, latar 3D, nampan, meja; verifikasi tangkapan layar di 4 ukuran |
| 2 | `geometry.js` dan 8 kue Fase 1 + `?preview=1`; verifikasi bentuk, warna, dan pemotongan |
| 3 | Inti game: gerak, jatuh, overlap, potong, skor, game over, `resetGame()` |
| 4 | Perfect, kombo, pemulihan lebar, kesulitan progresif |
| 5 | UI, HUD tepi layar, tombol fullscreen, rekor |
| 6 | 7 kue Fase 2, animasi, partikel, tahap latar, aksesibilitas, optimasi, pengujian akhir |
